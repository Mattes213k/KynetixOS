/*
 * packages/NexusLauncher/src/com/kynetix/nexuslauncher/feed/NexusSmartFeed.java
 * NexusSmartFeed — Left-swipe page on NexusLauncher home
 * KynetixOS 1.0
 *
 * Cards available:
 *   CARD_WEATHER     — Current weather + 3-day forecast
 *   CARD_CALENDAR    — Upcoming events (next 24h)
 *   CARD_SENTINEL    — SentinelLab security summary
 *   CARD_MEDIA       — Now playing / media controls
 *   CARD_RECENT_APPS — Recently used apps (horizontal scroll)
 *   CARD_BATTERY     — Battery status + estimated life
 *   CARD_NOTES       — Quick note input
 */

package com.kynetix.nexuslauncher.feed;

import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.kynetix.nexuslauncher.R;

import java.util.ArrayList;
import java.util.List;

public class NexusSmartFeed extends ScrollView {

    public static final int CARD_WEATHER     = 0;
    public static final int CARD_CALENDAR    = 1;
    public static final int CARD_SENTINEL    = 2;
    public static final int CARD_MEDIA       = 3;
    public static final int CARD_RECENT_APPS = 4;
    public static final int CARD_BATTERY     = 5;
    public static final int CARD_NOTES       = 6;

    private LinearLayout mCardContainer;
    private List<Integer> mCardOrder = new ArrayList<>();

    public NexusSmartFeed(Context ctx) { this(ctx, null); }
    public NexusSmartFeed(Context ctx, AttributeSet attrs) {
        super(ctx, attrs);
        init(ctx);
    }

    private void init(Context ctx) {
        setOverScrollMode(OVER_SCROLL_NEVER);
        mCardContainer = new LinearLayout(ctx);
        mCardContainer.setOrientation(LinearLayout.VERTICAL);
        mCardContainer.setPadding(dpToPx(16), dpToPx(72), dpToPx(16), dpToPx(24));
        addView(mCardContainer);
    }

    public void addCard(int cardType) {
        mCardOrder.add(cardType);
        View card = buildCard(cardType);
        if (card != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(12));
            mCardContainer.addView(card, lp);
        }
    }

    private View buildCard(int type) {
        switch (type) {
            case CARD_WEATHER:     return buildWeatherCard();
            case CARD_CALENDAR:    return buildCalendarCard();
            case CARD_SENTINEL:    return buildSentinelCard();
            case CARD_MEDIA:       return buildMediaCard();
            case CARD_RECENT_APPS: return buildRecentAppsCard();
            case CARD_BATTERY:     return buildBatteryCard();
            case CARD_NOTES:       return buildNotesCard();
            default:               return null;
        }
    }

    // ── Weather card ──────────────────────────────────────────────────────────

    private View buildWeatherCard() {
        View card = inflateCard();
        card.setBackgroundColor(0xFF1E2A3A); // Slightly blue-tinted dark

        TextView title = card.findViewById(R.id.card_title);
        TextView body  = card.findViewById(R.id.card_body);
        ImageView icon = card.findViewById(R.id.card_icon);

        title.setText("Weather");
        body.setText("Loading...");
        icon.setImageResource(R.drawable.ic_weather_partly_cloudy);

        // In production: bind to WeatherProvider / OWM API
        // For now: use placeholder
        card.post(() -> {
            body.setText("19°C — Partly Cloudy\n↓ 14° · ↑ 22° · Prague, CZ");
        });

        card.setOnClickListener(v ->
            getContext().startActivity(new Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("geo:50.0755,14.4378"))));

        return card;
    }

    // ── Calendar card ─────────────────────────────────────────────────────────

    private View buildCalendarCard() {
        View card = inflateCard();
        card.setBackgroundColor(0xFF1E1E2E);

        TextView title = card.findViewById(R.id.card_title);
        TextView body  = card.findViewById(R.id.card_body);
        ImageView icon = card.findViewById(R.id.card_icon);

        title.setText("Upcoming");
        icon.setImageResource(R.drawable.ic_calendar);

        // Query CalendarProvider for next 24h events
        String events = getUpcomingEvents();
        body.setText(events.isEmpty() ? "No events today" : events);

        card.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_APP_CALENDAR);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        });

        return card;
    }

    private String getUpcomingEvents() {
        // Query ContentResolver for calendar events in next 24h
        android.net.Uri uri = android.provider.CalendarContract.Events.CONTENT_URI;
        long now   = System.currentTimeMillis();
        long end   = now + 24 * 60 * 60 * 1000L;

        try {
            android.database.Cursor cursor = getContext().getContentResolver().query(
                uri,
                new String[]{
                    android.provider.CalendarContract.Events.TITLE,
                    android.provider.CalendarContract.Events.DTSTART,
                },
                android.provider.CalendarContract.Events.DTSTART + " >= ? AND "
                    + android.provider.CalendarContract.Events.DTSTART + " <= ?",
                new String[]{ String.valueOf(now), String.valueOf(end) },
                android.provider.CalendarContract.Events.DTSTART + " ASC"
            );

            if (cursor == null) return "";
            StringBuilder sb = new StringBuilder();
            int count = 0;
            while (cursor.moveToNext() && count < 3) {
                String evtTitle = cursor.getString(0);
                long   evtStart = cursor.getLong(1);
                String time = android.text.format.DateFormat
                    .getTimeFormat(getContext())
                    .format(new java.util.Date(evtStart));
                sb.append("• ").append(time).append("  ").append(evtTitle).append("\n");
                count++;
            }
            cursor.close();
            return sb.toString().trim();
        } catch (SecurityException e) {
            return "Calendar permission required";
        }
    }

    // ── SentinelLab card ──────────────────────────────────────────────────────

    private View buildSentinelCard() {
        View card = inflateCard();

        boolean clean  = SystemProperties.getBoolean("ro.sentinellab.boot_clean", false);
        boolean threat = SystemProperties.getBoolean("sentinellab.threat_detected", false);

        TextView title  = card.findViewById(R.id.card_title);
        TextView body   = card.findViewById(R.id.card_body);
        ImageView icon  = card.findViewById(R.id.card_icon);

        title.setText("SentinelLab");

        if (threat) {
            card.setBackgroundColor(0xFF2A1010);
            icon.setImageResource(R.drawable.ic_sentinel_threat);
            body.setText("⚠ Threat Detected\nTap to view details and resolve");
            body.setTextColor(0xFFFF1744);
        } else if (clean) {
            card.setBackgroundColor(0xFF0F2A1A);
            icon.setImageResource(R.drawable.ic_sentinel_shield);
            icon.setColorFilter(0xFF00C853);
            body.setText("✓ Secured by Nexus\nHW Level 3 · System verified\nLast scan: boot");
            body.setTextColor(0xFF00C853);
        } else {
            card.setBackgroundColor(0xFF1A1A2E);
            icon.setImageResource(R.drawable.ic_sentinel_shield);
            body.setText("SentinelLab scanning...");
        }

        card.setOnClickListener(v ->
            getContext().startActivity(
                new Intent("com.kynetix.nexusantivirus")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));

        return card;
    }

    // ── Media card ────────────────────────────────────────────────────────────

    private View buildMediaCard() {
        View card = inflateCard();
        card.setBackgroundColor(0xFF1A1A2A);
        card.setVisibility(View.GONE); // Hidden until media is playing

        TextView title = card.findViewById(R.id.card_title);
        title.setText("Now Playing");

        // In production: bind to MediaSessionManager for active sessions
        return card;
    }

    // ── Recent apps card ──────────────────────────────────────────────────────

    private View buildRecentAppsCard() {
        View card = inflateCard();
        card.setBackgroundColor(0xFF16162A);

        TextView title = card.findViewById(R.id.card_title);
        title.setText("Recent");

        // Horizontal RecyclerView of recent apps (from UsageStatsManager)
        // In production: query UsageStatsManager for top 8 recent apps

        return card;
    }

    // ── Battery card ──────────────────────────────────────────────────────────

    private View buildBatteryCard() {
        View card = inflateCard();
        card.setBackgroundColor(0xFF1A2A1A);

        TextView title = card.findViewById(R.id.card_title);
        TextView body  = card.findViewById(R.id.card_body);
        ImageView icon = card.findViewById(R.id.card_icon);

        title.setText("Battery");
        icon.setImageResource(R.drawable.ic_battery_full);
        body.setText("Loading battery info...");

        // Register battery receiver
        getContext().registerReceiver(new android.content.BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                int level   = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int scale   = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
                int status  = intent.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
                int pct     = (int)((level / (float) scale) * 100);
                boolean charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING;
                body.setText(pct + "%" + (charging ? " · Charging" : "") +
                    "\nEstimated: " + estimateBatteryLife(pct, charging));
            }
        }, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        return card;
    }

    private String estimateBatteryLife(int pct, boolean charging) {
        if (charging) return "~" + (int)((100 - pct) * 1.2) + " min to full";
        return "~" + (pct * 8) / 100 + "h " + ((pct * 8) % 100 * 60 / 100) + "min";
    }

    // ── Notes card ────────────────────────────────────────────────────────────

    private View buildNotesCard() {
        View card = inflateCard();
        card.setBackgroundColor(0xFF1E1A10);

        TextView title = card.findViewById(R.id.card_title);
        title.setText("Quick Note");
        // In production: editable TextView saved to SharedPreferences
        return card;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private View inflateCard() {
        return LayoutInflater.from(getContext())
            .inflate(R.layout.nexus_feed_card, null);
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
