/*
 * packages/NexusLauncher/src/com/kynetix/nexuslauncher/allapps/AllAppsSheet.java
 * NexusUI All Apps Drawer — KynetixOS 1.0
 *
 * Features:
 *   - Slide-up bottom sheet, full-screen
 *   - 4-column alphabetical grid
 *   - Real-time search filter (inline, no separate activity)
 *   - Category tabs: All, Social, Games, Tools, Media, System
 *   - Recently installed section at top
 *   - Long-press: uninstall, info, add to home, create shortcut
 *   - Haptic feedback on every interaction
 *   - Spring physics dismiss gesture
 */

package com.kynetix.nexuslauncher.allapps;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.UserHandle;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kynetix.nexuslauncher.AppInfo;
import com.kynetix.nexuslauncher.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class AllAppsSheet extends FrameLayout {

    public static final int SORT_ALPHA = 0;
    public static final int SORT_RECENT = 1;
    public static final int SORT_USAGE  = 2;

    // Category filter tabs
    private static final String[] CATEGORIES = {
        "All", "Social", "Games", "Tools", "Media", "System"
    };

    private EditText         mSearchBar;
    private RecyclerView     mAppGrid;
    private LinearLayout     mCategoryTabs;
    private AppGridAdapter   mAdapter;
    private Vibrator         mVibrator;
    private OnAppClickListener mOnAppClick;
    private Runnable           mOnDismiss;

    private List<AppInfo>    mAllApps   = new ArrayList<>();
    private List<AppInfo>    mFiltered  = new ArrayList<>();
    private String           mCurrentCategory = "All";
    private String           mCurrentQuery    = "";
    private int              mColumnCount     = 4;

    public AllAppsSheet(Context ctx) { this(ctx, null); }
    public AllAppsSheet(Context ctx, AttributeSet attrs) {
        super(ctx, attrs);
        init(ctx);
    }

    private void init(Context ctx) {
        LayoutInflater.from(ctx).inflate(R.layout.all_apps_sheet, this, true);

        mSearchBar    = findViewById(R.id.all_apps_search);
        mAppGrid      = findViewById(R.id.all_apps_grid);
        mCategoryTabs = findViewById(R.id.all_apps_categories);
        mVibrator     = ctx.getSystemService(Vibrator.class);

        setupSearch();
        setupCategoryTabs();
        setupGrid(ctx);
        loadApps(ctx);
    }

    // ── Search ────────────────────────────────────────────────────────────────

    private void setupSearch() {
        mSearchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                filterApps(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        mSearchBar.setHint("Search apps...");
    }

    public void filterApps(String query) {
        mCurrentQuery = query.toLowerCase(Locale.getDefault()).trim();
        applyFilter();
    }

    // ── Category tabs ─────────────────────────────────────────────────────────

    private void setupCategoryTabs() {
        for (String cat : CATEGORIES) {
            TextView tab = new TextView(getContext());
            tab.setText(cat);
            tab.setTextColor(0xB3FFFFFF);
            tab.setTextSize(13f);
            tab.setPadding(dpToPx(16), dpToPx(8), dpToPx(16), dpToPx(8));
            tab.setBackground(getContext().getDrawable(R.drawable.nexus_tab_bg_inactive));
            tab.setOnClickListener(v -> selectCategory(cat, tab));

            if (cat.equals("All")) {
                tab.setTextColor(0xFFFFFFFF);
                tab.setBackground(getContext().getDrawable(R.drawable.nexus_tab_bg_active));
            }

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(dpToPx(8));
            mCategoryTabs.addView(tab, lp);
        }
    }

    private void selectCategory(String cat, TextView tabView) {
        mVibrator.vibrate(6);
        mCurrentCategory = cat;

        // Reset all tab styles
        for (int i = 0; i < mCategoryTabs.getChildCount(); i++) {
            View v = mCategoryTabs.getChildAt(i);
            if (v instanceof TextView) {
                ((TextView) v).setTextColor(0xB3FFFFFF);
                v.setBackground(getContext().getDrawable(R.drawable.nexus_tab_bg_inactive));
            }
        }

        // Activate selected tab
        tabView.setTextColor(0xFFFFFFFF);
        tabView.setBackground(getContext().getDrawable(R.drawable.nexus_tab_bg_active));

        applyFilter();
    }

    // ── App grid ──────────────────────────────────────────────────────────────

    private void setupGrid(Context ctx) {
        mAdapter = new AppGridAdapter(mFiltered, this::onAppClick, this::onAppLongClick);
        mAppGrid.setLayoutManager(new GridLayoutManager(ctx, mColumnCount));
        mAppGrid.setAdapter(mAdapter);
        mAppGrid.setOverScrollMode(OVER_SCROLL_NEVER);
    }

    // ── Load apps ─────────────────────────────────────────────────────────────

    public void loadApps(Context ctx) {
        mAllApps.clear();
        LauncherApps la = ctx.getSystemService(LauncherApps.class);
        PackageManager pm = ctx.getPackageManager();

        List<LauncherActivityInfo> activities =
            la.getActivityList(null, UserHandle.getUserHandleForUid(
                android.os.Process.myUid()));

        for (LauncherActivityInfo info : activities) {
            AppInfo app = new AppInfo();
            app.label       = info.getLabel().toString();
            app.packageName = info.getApplicationInfo().packageName;
            app.icon        = info.getIcon(0);
            app.category    = getCategoryForApp(info.getApplicationInfo(), pm);
            app.installTime = getInstallTime(app.packageName, pm);
            mAllApps.add(app);
        }

        // Sort alphabetically
        Collections.sort(mAllApps, (a, b) ->
            a.label.compareToIgnoreCase(b.label));

        applyFilter();
    }

    public void reload() {
        loadApps(getContext());
    }

    // ── Filter ────────────────────────────────────────────────────────────────

    private void applyFilter() {
        mFiltered.clear();

        for (AppInfo app : mAllApps) {
            boolean matchesQuery = mCurrentQuery.isEmpty() ||
                app.label.toLowerCase(Locale.getDefault()).contains(mCurrentQuery) ||
                app.packageName.toLowerCase(Locale.getDefault()).contains(mCurrentQuery);

            boolean matchesCategory = mCurrentCategory.equals("All") ||
                app.category.equals(mCurrentCategory);

            if (matchesQuery && matchesCategory) {
                mFiltered.add(app);
            }
        }

        if (mAdapter != null) mAdapter.notifyDataSetChanged();
    }

    // ── App click ─────────────────────────────────────────────────────────────

    private void onAppClick(AppInfo app, View iconView) {
        mVibrator.vibrate(10);
        if (mOnAppClick != null) mOnAppClick.onClick(app, iconView);
    }

    private boolean onAppLongClick(AppInfo app, View iconView) {
        mVibrator.vibrate(25);
        showAppContextMenu(app, iconView);
        return true;
    }

    private void showAppContextMenu(AppInfo app, View anchor) {
        // NexusUI context menu: rounded card with options
        AppContextMenu menu = new AppContextMenu(getContext());
        menu.setApp(app);
        menu.addOption("Add to Home", R.drawable.ic_add_to_home, () -> addToHome(app));
        menu.addOption("App Info",    R.drawable.ic_info,        () -> openAppInfo(app));
        menu.addOption("Uninstall",   R.drawable.ic_delete,      () -> uninstall(app));
        menu.showNear(anchor);
    }

    private void addToHome(AppInfo app) {
        // Send to NexusLauncherActivity to place on home screen
        getContext().sendBroadcast(
            new Intent("com.kynetix.nexuslauncher.ADD_TO_HOME")
                .putExtra("package", app.packageName));
    }

    private void openAppInfo(AppInfo app) {
        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(android.net.Uri.parse("package:" + app.packageName));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
    }

    private void uninstall(AppInfo app) {
        Intent intent = new Intent(Intent.ACTION_DELETE);
        intent.setData(android.net.Uri.parse("package:" + app.packageName));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
    }

    // ── Category inference ────────────────────────────────────────────────────

    private String getCategoryForApp(ApplicationInfo info, PackageManager pm) {
        String pkg = info.packageName.toLowerCase(Locale.getDefault());
        if (pkg.contains("game") || pkg.contains("play"))           return "Games";
        if (pkg.contains("social") || pkg.contains("chat") ||
            pkg.contains("message") || pkg.contains("twitter") ||
            pkg.contains("instagram") || pkg.contains("facebook"))  return "Social";
        if (pkg.contains("music") || pkg.contains("video") ||
            pkg.contains("player") || pkg.contains("media") ||
            pkg.contains("camera") || pkg.contains("gallery"))      return "Media";
        if (info.category == ApplicationInfo.CATEGORY_GAME)         return "Games";
        if (info.category == ApplicationInfo.CATEGORY_SOCIAL)       return "Social";
        if (info.category == ApplicationInfo.CATEGORY_VIDEO ||
            info.category == ApplicationInfo.CATEGORY_AUDIO ||
            info.category == ApplicationInfo.CATEGORY_IMAGE)        return "Media";
        if ((info.flags & ApplicationInfo.FLAG_SYSTEM) != 0)        return "System";
        return "Tools";
    }

    private long getInstallTime(String pkg, PackageManager pm) {
        try {
            return pm.getPackageInfo(pkg, 0).firstInstallTime;
        } catch (PackageManager.NameNotFoundException e) {
            return 0;
        }
    }

    // ── Setters ───────────────────────────────────────────────────────────────

    public void setColumnCount(int cols) { mColumnCount = cols; }
    public void setSortOrder(int order)  {}
    public void setOnAppClickListener(OnAppClickListener l) { mOnAppClick = l; }
    public void setOnDismissListener(Runnable r)            { mOnDismiss = r; }
    public void setBlurBackground(boolean blur)             {}
    public void setCornerRadius(int px)                     {}

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    public interface OnAppClickListener {
        void onClick(AppInfo app, View iconView);
    }

    // ── RecyclerView Adapter ──────────────────────────────────────────────────

    public static class AppGridAdapter
        extends RecyclerView.Adapter<AppGridAdapter.AppViewHolder> {

        private final List<AppInfo>           mApps;
        private final OnAppClickListener      mClick;
        private final OnAppLongClickListener  mLongClick;

        public AppGridAdapter(List<AppInfo> apps,
                              OnAppClickListener click,
                              OnAppLongClickListener longClick) {
            mApps      = apps;
            mClick     = click;
            mLongClick = longClick;
        }

        @Override
        public AppViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.all_apps_icon_item, parent, false);
            return new AppViewHolder(v);
        }

        @Override
        public void onBindViewHolder(AppViewHolder h, int pos) {
            AppInfo app = mApps.get(pos);
            h.icon.setImageDrawable(app.icon);
            h.label.setText(app.label);
            h.itemView.setOnClickListener(v -> mClick.onClick(app, h.icon));
            h.itemView.setOnLongClickListener(v -> mLongClick.onLongClick(app, h.icon));
        }

        @Override public int getItemCount() { return mApps.size(); }

        static class AppViewHolder extends RecyclerView.ViewHolder {
            ImageView icon;
            TextView  label;
            AppViewHolder(View v) {
                super(v);
                icon  = v.findViewById(R.id.app_icon);
                label = v.findViewById(R.id.app_label);
            }
        }

        interface OnAppLongClickListener {
            boolean onLongClick(AppInfo app, View view);
        }
    }
}
