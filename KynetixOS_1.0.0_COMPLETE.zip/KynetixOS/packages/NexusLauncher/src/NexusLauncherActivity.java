/*
 * packages/NexusLauncher/src/com/kynetix/nexuslauncher/NexusLauncherActivity.java
 * NexusLauncher — Main Home Screen Activity
 * KynetixOS 1.0 | NexusUI Design Language
 *
 * Features:
 *   - Dock bar (4 icons, pill background)
 *   - Infinite scrolling home pages
 *   - Smart Folders with auto-categorization
 *   - Swipe-up All Apps drawer (NexusUI style)
 *   - Swipe-down notification shade passthrough
 *   - Left page: NexusSmartFeed (widgets + AI cards)
 *   - Long-press desktop: wallpaper / widgets / settings
 *   - SentinelLab status widget on home
 *   - Gesture navigation support
 */

package com.kynetix.nexuslauncher;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Intent;
import android.content.pm.LauncherApps;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemProperties;
import android.os.Vibrator;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

import com.kynetix.nexuslauncher.allapps.AllAppsSheet;
import com.kynetix.nexuslauncher.dock.NexusDock;
import com.kynetix.nexuslauncher.feed.NexusSmartFeed;
import com.kynetix.nexuslauncher.grid.HomePageView;
import com.kynetix.nexuslauncher.grid.HomeViewPager;
import com.kynetix.nexuslauncher.sentinel.SentinelStatusWidget;
import com.kynetix.nexuslauncher.search.NexusSearchBar;
import com.kynetix.nexuslauncher.widget.NexusWidgetHost;

public class NexusLauncherActivity extends Activity {

    // Layout constants — NexusUI grid
    public static final int GRID_COLS         = 4;
    public static final int GRID_ROWS         = 6;
    public static final int DOCK_ITEMS        = 4;
    public static final int ICON_SIZE_DP      = 60;
    public static final int ICON_PADDING_DP   = 12;
    public static final int CORNER_RADIUS_DP  = 24;

    // Animation durations (NexusUI motion spec)
    private static final int ANIM_APP_LAUNCH  = 300;
    private static final int ANIM_SHEET_OPEN  = 400;
    private static final int ANIM_SHEET_CLOSE = 280;
    private static final int ANIM_PAGE_SWITCH = 250;

    // Views
    private FrameLayout        mRoot;
    private HomeViewPager      mHomeViewPager;
    private NexusDock          mDock;
    private AllAppsSheet       mAllAppsSheet;
    private NexusSearchBar     mSearchBar;
    private NexusSmartFeed     mSmartFeed;
    private SentinelStatusWidget mSentinelWidget;
    private NexusWidgetHost    mWidgetHost;

    // State
    private boolean            mAllAppsOpen    = false;
    private boolean            mSmartFeedOpen  = false;
    private GestureDetector    mGestureDetector;
    private Vibrator           mVibrator;
    private LauncherApps       mLauncherApps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full-screen immersive with gesture nav
        setupWindow();

        // Inflate NexusUI home layout
        setContentView(R.layout.activity_nexus_launcher);

        mRoot          = findViewById(R.id.launcher_root);
        mHomeViewPager = findViewById(R.id.home_viewpager);
        mDock          = findViewById(R.id.nexus_dock);
        mAllAppsSheet  = findViewById(R.id.all_apps_sheet);
        mSearchBar     = findViewById(R.id.nexus_search);
        mSentinelWidget = findViewById(R.id.sentinel_widget);

        mVibrator    = getSystemService(Vibrator.class);
        mLauncherApps = getSystemService(LauncherApps.class);

        // Setup components
        setupHomeGrid();
        setupDock();
        setupAllAppsSheet();
        setupSearchBar();
        setupGestures();
        setupSentinelWidget();
        setupSmartFeed();
        setupWallpaper();
    }

    // ── Window setup ──────────────────────────────────────────────────────────

    private void setupWindow() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        // Light/dark icons based on wallpaper
        WindowInsetsController wic = getWindow().getInsetsController();
        if (wic != null) {
            wic.setSystemBarsAppearance(0,
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
        }
    }

    // ── Home grid ─────────────────────────────────────────────────────────────

    private void setupHomeGrid() {
        // Left page: NexusSmartFeed
        // Pages 1+: App icon grid (4×6)
        mHomeViewPager.setAdapter(new HomePageAdapter(this, GRID_COLS, GRID_ROWS));
        mHomeViewPager.setCurrentItem(1, false); // Start on first icon page
        mHomeViewPager.setPageTransformer(new NexusPageTransformer()); // Parallax effect
        mHomeViewPager.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    // ── Dock ──────────────────────────────────────────────────────────────────

    private void setupDock() {
        // 4-item dock with pill background, blur, and NexusUI shadow
        mDock.setItemCount(DOCK_ITEMS);
        mDock.setBlurEnabled(true);
        mDock.setBlurRadius(20);
        mDock.setCornerRadius(dpToPx(28));
        mDock.setBackgroundColor(0x33FFFFFF); // Glass effect

        // Default dock: Phone, Messages, Chrome→Aurora, Camera, App Drawer trigger
        mDock.loadSavedApps();

        // App drawer trigger: swipe up from dock
        mDock.setOnSwipeUpListener(() -> openAllApps(true));
    }

    // ── All Apps sheet ────────────────────────────────────────────────────────

    private void setupAllAppsSheet() {
        mAllAppsSheet.setVisibility(View.INVISIBLE);
        mAllAppsSheet.setTranslationY(getWindowHeight());
        mAllAppsSheet.setBlurBackground(true);
        mAllAppsSheet.setCornerRadius(dpToPx(28));
        mAllAppsSheet.setBackgroundColor(0xCC0A0A0F);

        // Grid: 4 columns, alphabetical, with search
        mAllAppsSheet.setColumnCount(GRID_COLS);
        mAllAppsSheet.setSortOrder(AllAppsSheet.SORT_ALPHA);
        mAllAppsSheet.setOnAppClickListener(this::launchApp);
        mAllAppsSheet.setOnDismissListener(() -> closeAllApps());
    }

    public void openAllApps(boolean animate) {
        if (mAllAppsOpen) return;
        mAllAppsOpen = true;
        mAllAppsSheet.setVisibility(View.VISIBLE);
        mVibrator.vibrate(8); // Haptic

        if (animate) {
            AnimatorSet set = new AnimatorSet();
            ObjectAnimator slideUp = ObjectAnimator.ofFloat(
                mAllAppsSheet, "translationY", getWindowHeight(), 0f);
            ObjectAnimator fadeIn  = ObjectAnimator.ofFloat(mAllAppsSheet, "alpha", 0f, 1f);
            set.playTogether(slideUp, fadeIn);
            set.setDuration(ANIM_SHEET_OPEN);
            set.setInterpolator(new DecelerateInterpolator(2.5f));
            set.start();
        }
    }

    public void closeAllApps() {
        if (!mAllAppsOpen) return;
        mAllAppsOpen = false;

        AnimatorSet set = new AnimatorSet();
        ObjectAnimator slideDown = ObjectAnimator.ofFloat(
            mAllAppsSheet, "translationY", 0f, getWindowHeight());
        ObjectAnimator fadeOut   = ObjectAnimator.ofFloat(mAllAppsSheet, "alpha", 1f, 0f);
        set.playTogether(slideDown, fadeOut);
        set.setDuration(ANIM_SHEET_CLOSE);
        set.setInterpolator(new DecelerateInterpolator(2f));
        set.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                mAllAppsSheet.setVisibility(View.INVISIBLE);
            }
        });
        set.start();
    }

    // ── App launch animation ──────────────────────────────────────────────────

    private void launchApp(AppInfo app, View iconView) {
        mVibrator.vibrate(12);

        // Scale-from-icon launch animation
        int[] loc = new int[2];
        iconView.getLocationOnScreen(loc);

        float startX = loc[0] + iconView.getWidth() / 2f;
        float startY = loc[1] + iconView.getHeight() / 2f;

        // NexusUI: ripple from icon, then activity opens
        iconView.animate()
            .scaleX(0.85f).scaleY(0.85f)
            .setDuration(80)
            .withEndAction(() -> {
                iconView.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                // Start the app
                Intent intent = getPackageManager()
                    .getLaunchIntentForPackage(app.packageName);
                if (intent != null) {
                    // Custom activity options: scale-up from icon position
                    startActivity(intent,
                        android.app.ActivityOptions
                            .makeScaleUpAnimation(iconView, 0, 0,
                                iconView.getWidth(), iconView.getHeight())
                            .toBundle());
                }
            }).start();
    }

    // ── Search bar ───────────────────────────────────────────────────────────

    private void setupSearchBar() {
        // NexusUI pill search bar at top of home
        mSearchBar.setCornerRadius(dpToPx(24));
        mSearchBar.setBackgroundColor(0x26FFFFFF); // Frosted glass
        mSearchBar.setHint("Search apps, contacts, web...");
        mSearchBar.setOnClickListener(v -> openAllApps(true));
        mSearchBar.setOnQueryListener(query -> {
            if (mAllAppsOpen) mAllAppsSheet.filterApps(query);
        });
    }

    // ── SentinelLab status widget ─────────────────────────────────────────────

    private void setupSentinelWidget() {
        boolean sentinelClean = SystemProperties.getBoolean("ro.sentinellab.boot_clean", false);
        mSentinelWidget.setStatus(sentinelClean
            ? SentinelStatusWidget.STATUS_SECURE
            : SentinelStatusWidget.STATUS_WARNING);
        mSentinelWidget.setLabel(sentinelClean ? "Secured by Nexus" : "SentinelLab — Check required");
        mSentinelWidget.setOnClickListener(v -> {
            startActivity(new Intent("com.kynetix.sentinellab.UI"));
        });
    }

    // ── SmartFeed (left page) ─────────────────────────────────────────────────

    private void setupSmartFeed() {
        // Left swipe from home = NexusSmartFeed
        // Contains: weather, calendar, SentinelLab summary, recent apps, media player
        mSmartFeed = new NexusSmartFeed(this);
        mSmartFeed.addCard(NexusSmartFeed.CARD_WEATHER);
        mSmartFeed.addCard(NexusSmartFeed.CARD_CALENDAR);
        mSmartFeed.addCard(NexusSmartFeed.CARD_SENTINEL);
        mSmartFeed.addCard(NexusSmartFeed.CARD_MEDIA);
        mSmartFeed.addCard(NexusSmartFeed.CARD_RECENT_APPS);
    }

    // ── Gestures ──────────────────────────────────────────────────────────────

    private void setupGestures() {
        mGestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            private static final int SWIPE_THRESHOLD   = 100;
            private static final int SWIPE_VELOCITY    = 100;

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2,
                                   float vX, float vY) {
                float dX = e2.getX() - e1.getX();
                float dY = e2.getY() - e1.getY();

                // Swipe up → open All Apps
                if (Math.abs(dY) > Math.abs(dX)
                    && -dY > SWIPE_THRESHOLD
                    && Math.abs(vY) > SWIPE_VELOCITY) {
                    if (!mAllAppsOpen) openAllApps(true);
                    return true;
                }

                // Swipe down → close All Apps / open notification shade
                if (Math.abs(dY) > Math.abs(dX)
                    && dY > SWIPE_THRESHOLD
                    && Math.abs(vY) > SWIPE_VELOCITY) {
                    if (mAllAppsOpen) {
                        closeAllApps();
                    } else {
                        // Pass to SystemUI to open notification shade
                        expandStatusBar();
                    }
                    return true;
                }
                return false;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                // Long press desktop → show wallpaper/widget picker
                mVibrator.vibrate(30);
                showDesktopOptionsMenu();
            }
        });

        mRoot.setOnTouchListener((v, event) -> mGestureDetector.onTouchEvent(event));
    }

    // ── Wallpaper ─────────────────────────────────────────────────────────────

    private void setupWallpaper() {
        WallpaperManager wm = WallpaperManager.getInstance(this);
        // Apply default KynetixOS wallpaper if none set
        if (wm.getWallpaperInfo() == null) {
            try {
                wm.setResource(R.drawable.wallpaper_kynetix_default);
            } catch (Exception ignored) {}
        }
    }

    // ── Desktop options ───────────────────────────────────────────────────────

    private void showDesktopOptionsMenu() {
        // Bottom sheet with: Wallpapers, Widgets, Home Settings, NexusUI
        DesktopOptionsSheet sheet = new DesktopOptionsSheet(this);
        sheet.show(getFragmentManager(), "desktop_options");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void expandStatusBar() {
        try {
            Object service = getSystemService("statusbar");
            if (service != null) {
                service.getClass()
                    .getMethod("expandNotificationsPanel")
                    .invoke(service);
            }
        } catch (Exception ignored) {}
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private int getWindowHeight() {
        return getWindowManager().getCurrentWindowMetrics()
            .getBounds().height();
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        if (mAllAppsOpen) {
            closeAllApps();
        } else {
            // Home key behavior — go to page 1
            mHomeViewPager.setCurrentItem(1, true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAllAppsSheet != null) mAllAppsSheet.reload();
        if (mSentinelWidget != null) mSentinelWidget.refresh();
    }
}
