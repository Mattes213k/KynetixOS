/*
 * packages/NexusSettings/src/com/kynetix/settings/NexusSettingsActivity.java
 * NexusSettings — KynetixOS System Settings
 * Full settings app with NexusUI design, SentinelLab panel, and KynetixOS controls
 */

package com.kynetix.settings;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemProperties;
import android.preference.PreferenceFragment;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NexusSettingsActivity extends Activity {

    // Top-level settings categories
    public static final String[] CATEGORIES = {
        "Network & Internet",
        "Connected devices",
        "Apps",
        "Notifications",
        "Battery",
        "Display",
        "Sound & vibration",
        "Storage",
        "Privacy",
        "Location",
        "Security",          // SentinelLab integrated here
        "Accounts",
        "Accessibility",
        "NexusUI",           // KynetixOS exclusive
        "KynetixOS",         // OS version, build info, updates
        "System",
        "About phone"
    };

    private LinearLayout mCategoryList;
    private View         mDetailPane;   // Two-pane on tablet

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nexus_settings);

        // NexusUI action bar
        setupActionBar();

        mCategoryList = findViewById(R.id.settings_category_list);
        mDetailPane   = findViewById(R.id.settings_detail_pane);

        buildCategoryList();

        // Handle direct intent (e.g. from NexusAntivirus)
        handleDirectIntent(getIntent());
    }

    private void setupActionBar() {
        // NexusUI top bar: back arrow + "Settings" title
        TextView title = findViewById(R.id.settings_title);
        if (title != null) title.setText("Settings");
        ImageView back = findViewById(R.id.settings_back);
        if (back != null) back.setOnClickListener(v -> finish());
    }

    private void buildCategoryList() {
        for (String cat : CATEGORIES) {
            NexusSettingsCategory view = new NexusSettingsCategory(this);
            view.setTitle(cat);
            view.setIcon(getCategoryIcon(cat));
            view.setSummary(getCategorySummary(cat));
            view.setOnClickListener(v -> openCategory(cat));
            mCategoryList.addView(view);
        }
    }

    private void openCategory(String category) {
        Class<? extends PreferenceFragment> frag = getFragmentForCategory(category);
        if (frag != null) {
            getFragmentManager().beginTransaction()
                .replace(R.id.settings_detail_pane, frag.newInstance())
                .addToBackStack(category)
                .commit();
        }
    }

    private Class<? extends PreferenceFragment> getFragmentForCategory(String cat) {
        switch (cat) {
            case "Network & Internet":  return NetworkSettingsFragment.class;
            case "Connected devices":   return ConnectedDevicesFragment.class;
            case "Apps":                return AppsFragment.class;
            case "Notifications":       return NotificationsFragment.class;
            case "Battery":             return BatteryFragment.class;
            case "Display":             return DisplayFragment.class;
            case "Sound & vibration":   return SoundFragment.class;
            case "Storage":             return StorageFragment.class;
            case "Privacy":             return PrivacyFragment.class;
            case "Location":            return LocationFragment.class;
            case "Security":            return SecuritySentinelFragment.class;
            case "Accounts":            return AccountsFragment.class;
            case "Accessibility":       return AccessibilityFragment.class;
            case "NexusUI":             return NexusUIFragment.class;
            case "KynetixOS":           return KynetixOSFragment.class;
            case "System":              return SystemFragment.class;
            case "About phone":         return AboutFragment.class;
            default:                    return null;
        }
    }

    private int getCategoryIcon(String cat) {
        switch (cat) {
            case "Network & Internet":  return R.drawable.ic_settings_wifi;
            case "Connected devices":   return R.drawable.ic_settings_bluetooth;
            case "Apps":                return R.drawable.ic_settings_apps;
            case "Notifications":       return R.drawable.ic_settings_notifications;
            case "Battery":             return R.drawable.ic_settings_battery;
            case "Display":             return R.drawable.ic_settings_display;
            case "Sound & vibration":   return R.drawable.ic_settings_sound;
            case "Storage":             return R.drawable.ic_settings_storage;
            case "Privacy":             return R.drawable.ic_settings_privacy;
            case "Location":            return R.drawable.ic_settings_location;
            case "Security":            return R.drawable.ic_sentinel_shield;
            case "Accounts":            return R.drawable.ic_settings_account;
            case "Accessibility":       return R.drawable.ic_settings_accessibility;
            case "NexusUI":             return R.drawable.ic_nexusui_logo;
            case "KynetixOS":           return R.drawable.ic_kynetix_logo;
            case "System":              return R.drawable.ic_settings_system;
            case "About phone":         return R.drawable.ic_settings_info;
            default:                    return R.drawable.ic_settings_default;
        }
    }

    private String getCategorySummary(String cat) {
        switch (cat) {
            case "Security":
                boolean clean = SystemProperties.getBoolean("ro.sentinellab.boot_clean", false);
                return clean ? "SentinelLab: Secured by Nexus" : "SentinelLab: Check required";
            case "NexusUI":
                return "Themes, fonts, icons, animations";
            case "KynetixOS":
                return "v" + SystemProperties.get("ro.kynetix.version", "1.0.0")
                    + " · " + SystemProperties.get("ro.kynetix.codename", "Sapphire");
            default: return null;
        }
    }

    private void handleDirectIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (action == null) return;
        switch (action) {
            case "com.kynetix.nexusantivirus.SETTINGS":
                openCategory("Security");
                break;
            case "com.kynetix.sentinellab.SETTINGS":
                openCategory("Security");
                break;
            case "com.kynetix.nexuslauncher.settings.NexusLauncherSettings":
                openCategory("NexusUI");
                break;
        }
    }
}
