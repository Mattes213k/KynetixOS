/*
 * packages/NexusSettings/src/com/kynetix/settings/SecuritySentinelFragment.java
 * Security & SentinelLab Settings Fragment — KynetixOS 1.0
 *
 * Full security settings panel integrating:
 *   - SentinelLab hardware scan controls
 *   - NexusAntivirus management
 *   - Screen lock / biometric
 *   - Privacy dashboard
 *   - Permission manager
 *   - Encryption status
 */

package com.kynetix.settings;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.SystemProperties;
import android.preference.Preference;
import android.preference.PreferenceCategory;
import android.preference.PreferenceFragment;
import android.preference.SwitchPreference;
import android.widget.Toast;

public class SecuritySentinelFragment extends PreferenceFragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.security_sentinel_prefs);

        setupSentinelStatus();
        setupSentinelControls();
        setupAntivirusControls();
        setupScreenLock();
        setupEncryption();
        setupPermissions();
    }

    // ── SentinelLab status ────────────────────────────────────────────────────

    private void setupSentinelStatus() {
        Preference statusPref = findPreference("sentinel_status_banner");
        boolean clean  = SystemProperties.getBoolean("ro.sentinellab.boot_clean", false);
        boolean threat = SystemProperties.getBoolean("sentinellab.threat_detected", false);

        if (statusPref != null) {
            if (threat) {
                statusPref.setTitle("⚠ Threat Detected");
                statusPref.setSummary("SentinelLab detected a security issue. Tap for details.");
                statusPref.setIcon(R.drawable.ic_sentinel_threat);
            } else if (clean) {
                statusPref.setTitle("✓ Secured by Nexus");
                statusPref.setSummary("SentinelLab: System integrity verified. Hardware Level 3.");
                statusPref.setIcon(R.drawable.ic_sentinel_shield_green);
            } else {
                statusPref.setTitle("SentinelLab");
                statusPref.setSummary("Status unknown. Run scan to verify.");
                statusPref.setIcon(R.drawable.ic_sentinel_shield);
            }

            statusPref.setOnPreferenceClickListener(pref -> {
                startActivity(new android.content.Intent("com.kynetix.sentinellab.UI"));
                return true;
            });
        }

        // HW permission level
        Preference hwLevel = findPreference("sentinel_hw_level");
        if (hwLevel != null) {
            hwLevel.setSummary("Level " +
                SystemProperties.get("ro.sentinellab.hw_permission_level", "3") +
                " — Full hardware access (TEE/QSEE)");
        }

        // Last scan
        Preference lastScan = findPreference("sentinel_last_scan");
        if (lastScan != null) {
            String ts = SystemProperties.get("sentinellab.last_scan_time", "Never");
            lastScan.setSummary(ts);
        }
    }

    // ── SentinelLab controls ──────────────────────────────────────────────────

    private void setupSentinelControls() {
        // Realtime monitoring toggle
        SwitchPreference rtPref = (SwitchPreference) findPreference("sentinel_realtime");
        if (rtPref != null) {
            rtPref.setChecked(
                SystemProperties.getBoolean("ro.sentinellab.realtime_monitor", true));
            rtPref.setOnPreferenceChangeListener((pref, val) -> {
                SystemProperties.set("ro.sentinellab.realtime_monitor",
                    (Boolean) val ? "true" : "false");
                return true;
            });
        }

        // Network firewall toggle
        SwitchPreference fwPref = (SwitchPreference) findPreference("sentinel_network_fw");
        if (fwPref != null) {
            fwPref.setChecked(
                SystemProperties.getBoolean("ro.sentinellab.network_firewall", true));
            fwPref.setOnPreferenceChangeListener((pref, val) -> {
                SystemProperties.set("ro.sentinellab.network_firewall",
                    (Boolean) val ? "true" : "false");
                getActivity().sendBroadcast(
                    new android.content.Intent("com.kynetix.sentinel.FIREWALL_TOGGLE")
                        .putExtra("enabled", (Boolean) val));
                return true;
            });
        }

        // Kernel scan toggle
        SwitchPreference kPref = (SwitchPreference) findPreference("sentinel_kernel_scan");
        if (kPref != null) {
            kPref.setChecked(
                SystemProperties.getBoolean("ro.sentinellab.kernel_scan", true));
        }

        // Run scan now
        Preference scanNow = findPreference("sentinel_scan_now");
        if (scanNow != null) {
            scanNow.setOnPreferenceClickListener(pref -> {
                runFullScan();
                return true;
            });
        }

        // Scan history
        Preference history = findPreference("sentinel_scan_history");
        if (history != null) {
            history.setOnPreferenceClickListener(pref -> {
                startActivity(new android.content.Intent(
                    "com.kynetix.sentinellab.SCAN_HISTORY"));
                return true;
            });
        }

        // Threat response mode
        Preference threatMode = findPreference("sentinel_threat_response");
        if (threatMode != null) {
            threatMode.setSummary("Lockdown on critical threat");
        }
    }

    // ── NexusAntivirus ────────────────────────────────────────────────────────

    private void setupAntivirusControls() {
        Preference dbVer = findPreference("nexusav_db_version");
        if (dbVer != null) {
            dbVer.setSummary("v2025.1 — " +
                SystemProperties.get("ro.nexusav.db_date", "2025-05-01"));
        }

        SwitchPreference bootScan = (SwitchPreference) findPreference("nexusav_boot_scan");
        if (bootScan != null) {
            bootScan.setChecked(
                SystemProperties.getBoolean("ro.nexusav.boot_scan", true));
        }

        Preference updateDb = findPreference("nexusav_update_db");
        if (updateDb != null) {
            updateDb.setOnPreferenceClickListener(pref -> {
                updateSignatureDatabase();
                return true;
            });
        }

        Preference quarantine = findPreference("nexusav_quarantine");
        if (quarantine != null) {
            quarantine.setOnPreferenceClickListener(pref -> {
                startActivity(new android.content.Intent(
                    "com.kynetix.nexusantivirus.QUARANTINE"));
                return true;
            });
        }
    }

    // ── Screen lock ───────────────────────────────────────────────────────────

    private void setupScreenLock() {
        Preference lockPref = findPreference("screen_lock_type");
        if (lockPref != null) {
            lockPref.setOnPreferenceClickListener(pref -> {
                startActivity(new android.content.Intent(
                    android.provider.Settings.ACTION_SECURITY_SETTINGS));
                return true;
            });
        }

        Preference fpPref = findPreference("fingerprint_settings");
        if (fpPref != null) {
            fpPref.setOnPreferenceClickListener(pref -> {
                startActivity(new android.content.Intent(
                    "android.settings.FINGERPRINT_ENROLL"));
                return true;
            });
        }
    }

    // ── Encryption ────────────────────────────────────────────────────────────

    private void setupEncryption() {
        Preference encPref = findPreference("device_encryption");
        if (encPref != null) {
            // KynetixOS always encrypted (FBE enforced)
            encPref.setSummary("File-based encryption (FBE) — Active");
            encPref.setEnabled(false);
        }

        Preference dmVerity = findPreference("dm_verity_status");
        if (dmVerity != null) {
            boolean dvOk = SystemProperties.getBoolean("ro.sentinellab.dm_verity_ok", true);
            dmVerity.setSummary(dvOk
                ? "dm-verity enforced — System verified"
                : "⚠ dm-verity error detected");
        }
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private void setupPermissions() {
        Preference permMgr = findPreference("permission_manager");
        if (permMgr != null) {
            permMgr.setOnPreferenceClickListener(pref -> {
                startActivity(new android.content.Intent(
                    android.provider.Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS));
                return true;
            });
        }
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    private void runFullScan() {
        new AlertDialog.Builder(getActivity())
            .setTitle("Run SentinelLab Full Scan")
            .setMessage("This will perform a complete hardware + system scan. Continue?")
            .setPositiveButton("Scan Now", (d, w) -> {
                getActivity().sendBroadcast(
                    new android.content.Intent("com.kynetix.sentinel.SCAN_NOW"));
                Toast.makeText(getActivity(), "SentinelLab scan started…",
                    Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void updateSignatureDatabase() {
        Toast.makeText(getActivity(), "Checking for signature updates…",
            Toast.LENGTH_SHORT).show();
        getActivity().sendBroadcast(
            new android.content.Intent("com.kynetix.nexusantivirus.UPDATE_DB"));
    }
}
