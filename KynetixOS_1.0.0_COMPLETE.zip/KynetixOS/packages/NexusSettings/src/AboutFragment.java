/*
 * packages/NexusSettings/src/com/kynetix/settings/AboutFragment.java
 * About Phone — KynetixOS 1.0
 * Full device info, software versions, Easter egg, OTA updates
 */

package com.kynetix.settings;

import android.os.Build;
import android.os.Bundle;
import android.os.SystemProperties;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.widget.Toast;

public class AboutFragment extends PreferenceFragment {

    private int mDevOptionsCount = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.about_prefs);

        populate();
        setupOTAUpdate();
        setupDeveloperOptions();
    }

    private void populate() {
        set("about_kynetix_version",
            "KynetixOS " + SystemProperties.get("ro.kynetix.version", "1.0.0")
            + " (" + SystemProperties.get("ro.kynetix.codename", "Sapphire") + ")"
        );
        set("about_nexusui_version", "NexusUI 1.0");
        set("about_sentinel_version",
            "SentinelLab 1.0.0 — Secured by Nexus");
        set("about_build_type",
            SystemProperties.get("ro.kynetix.build.type", "OFFICIAL"));
        set("about_build_date",
            SystemProperties.get("ro.kynetix.build.date", "20250526"));
        set("about_android_version", "Android " + Build.VERSION.RELEASE);
        set("about_security_patch",
            SystemProperties.get("ro.build.version.security_patch", "2025-05-01"));
        set("about_kernel_version",
            System.getProperty("os.version", "5.15.x-kynetix"));
        set("about_device_model", Build.MODEL);
        set("about_device_soc", "Qualcomm Snapdragon 7s Gen 2 (SM7435)");
        set("about_baseband",
            SystemProperties.get("gsm.version.baseband", "Unknown"));
        set("about_build_fingerprint",
            SystemProperties.get("ro.build.fingerprint", ""));
        set("about_sentinel_hw_level",
            "Hardware Permission Level " +
            SystemProperties.get("ro.sentinellab.hw_permission_level", "3"));

        // Aurora Store
        set("about_aurora_version", "Aurora Store 4.4.x (Bundled)");
    }

    private void set(String key, String summary) {
        Preference p = findPreference(key);
        if (p != null) p.setSummary(summary);
    }

    private void setupOTAUpdate() {
        Preference ota = findPreference("about_ota_update");
        if (ota != null) {
            ota.setOnPreferenceClickListener(pref -> {
                startActivity(new android.content.Intent(
                    "com.kynetix.updater.CHECK_UPDATE"));
                return true;
            });
        }
    }

    private void setupDeveloperOptions() {
        Preference buildNum = findPreference("about_build_number");
        if (buildNum != null) {
            buildNum.setSummary(
                SystemProperties.get("ro.kynetix.build.date", "20250526") +
                ".kynetix-" + SystemProperties.get("ro.kynetix.build.type","OFFICIAL").toLowerCase()
            );
            buildNum.setOnPreferenceClickListener(pref -> {
                mDevOptionsCount++;
                if (mDevOptionsCount >= 7) {
                    // Enable developer options
                    android.provider.Settings.Global.putInt(
                        getActivity().getContentResolver(),
                        android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 1);
                    Toast.makeText(getActivity(),
                        "You are now a developer!", Toast.LENGTH_SHORT).show();
                } else if (mDevOptionsCount >= 4) {
                    int left = 7 - mDevOptionsCount;
                    Toast.makeText(getActivity(),
                        left + " steps away from Developer Options",
                        Toast.LENGTH_SHORT).show();
                }
                return true;
            });
        }
    }
}
