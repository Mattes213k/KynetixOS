/*
 * packages/NexusSettings/src/com/kynetix/settings/NexusUIFragment.java
 * NexusUI Settings — KynetixOS 1.0
 * Theme engine, font picker, icon packs, animations, and display tuning
 */

package com.kynetix.settings;

import android.app.AlertDialog;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemProperties;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.SeekBarPreference;
import android.preference.SwitchPreference;
import android.view.View;
import android.widget.Toast;

public class NexusUIFragment extends PreferenceFragment {

    // Accent color options
    private static final String[] ACCENT_NAMES  = {
        "Nexus Blue", "Nexus Cyan", "Nexus Purple",
        "Nexus Green", "Nexus Red", "Nexus Orange",
        "Nexus Pink", "Nexus Gold", "Custom"
    };
    private static final int[] ACCENT_VALUES = {
        0xFF2979FF, 0xFF00E5FF, 0xFF7C4DFF,
        0xFF00C853, 0xFFFF1744, 0xFFFF6D00,
        0xFFE91E63, 0xFFFFD700, 0xFF000000
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.nexusui_prefs);

        setupThemeSection();
        setupFontSection();
        setupIconSection();
        setupStatusBarSection();
        setupLockScreenSection();
        setupAnimationSection();
        setupDisplaySection();
        setupAdvancedSection();
    }

    // ── Theme ─────────────────────────────────────────────────────────────────

    private void setupThemeSection() {
        // Theme style
        ListPreference themePref = (ListPreference) findPreference("nexusui_theme");
        if (themePref != null) {
            themePref.setEntries(new String[]{"Dark (Default)", "Light", "Auto (System)"});
            themePref.setEntryValues(new String[]{"dark", "light", "auto"});
            themePref.setValue(
                SystemProperties.get("persist.sys.nexusui.theme", "dark"));
            themePref.setOnPreferenceChangeListener((pref, val) -> {
                SystemProperties.set("persist.sys.nexusui.theme", (String) val);
                applyTheme((String) val);
                return true;
            });
        }

        // Accent color picker
        Preference accentPref = findPreference("nexusui_accent_color");
        if (accentPref != null) {
            int currentAccent = SystemProperties.getInt(
                "persist.sys.nexusui.accent_color", 0xFF2979FF);
            accentPref.setSummary(getAccentName(currentAccent));
            accentPref.setOnPreferenceClickListener(pref -> {
                showAccentColorPicker();
                return true;
            });
        }

        // Blur effects
        SwitchPreference blurPref = (SwitchPreference) findPreference("nexusui_blur");
        if (blurPref != null) {
            blurPref.setChecked(
                SystemProperties.getBoolean("persist.sys.nexusui.blur_enabled", true));
            blurPref.setOnPreferenceChangeListener((pref, val) -> {
                SystemProperties.set("persist.sys.nexusui.blur_enabled",
                    (Boolean) val ? "true" : "false");
                return true;
            });
        }

        // Blur radius
        SeekBarPreference blurRadius = (SeekBarPreference) findPreference("nexusui_blur_radius");
        if (blurRadius != null) {
            blurRadius.setMax(60);
            blurRadius.setValue(
                SystemProperties.getInt("persist.sys.nexusui.blur_radius", 30));
        }

        // Corner radius
        SeekBarPreference cornerPref = (SeekBarPreference) findPreference("nexusui_corner_radius");
        if (cornerPref != null) {
            cornerPref.setMax(40);
            cornerPref.setValue(
                SystemProperties.getInt("persist.sys.nexusui.corner_radius", 24));
            cornerPref.setOnPreferenceChangeListener((pref, val) -> {
                SystemProperties.set("persist.sys.nexusui.corner_radius",
                    String.valueOf((Integer) val));
                return true;
            });
        }
    }

    // ── Font ──────────────────────────────────────────────────────────────────

    private void setupFontSection() {
        ListPreference fontPref = (ListPreference) findPreference("nexusui_font");
        if (fontPref != null) {
            fontPref.setEntries(new String[]{
                "Nexus Display (Default)", "Roboto", "Inter",
                "OnePlus Slate", "Samsung One UI Sans", "System Default"
            });
            fontPref.setEntryValues(new String[]{
                "nexus_display", "roboto", "inter",
                "oneplus_slate", "samsung_one_ui", "system"
            });
            fontPref.setValue(
                SystemProperties.get("persist.sys.nexusui.font", "nexus_display"));
            fontPref.setOnPreferenceChangeListener((pref, val) -> {
                SystemProperties.set("persist.sys.nexusui.font", (String) val);
                Toast.makeText(getActivity(),
                    "Font changed. Restart launcher to apply.", Toast.LENGTH_SHORT).show();
                return true;
            });
        }

        // Font scale
        SeekBarPreference fontScale = (SeekBarPreference) findPreference("nexusui_font_scale");
        if (fontScale != null) {
            fontScale.setMax(150);
            fontScale.setValue(100);
        }
    }

    // ── Icons ─────────────────────────────────────────────────────────────────

    private void setupIconSection() {
        ListPreference iconPref = (ListPreference) findPreference("nexusui_icon_pack");
        if (iconPref != null) {
            iconPref.setEntries(new String[]{
                "Nexus Icons (Default)", "Material You", "Pixel",
                "Fluent", "Carbon", "System Default"
            });
            iconPref.setEntryValues(new String[]{
                "nexus_icons", "material_you", "pixel",
                "fluent", "carbon", "system"
            });
        }

        // Icon shape
        ListPreference iconShape = (ListPreference) findPreference("nexusui_icon_shape");
        if (iconShape != null) {
            iconShape.setEntries(new String[]{
                "Rounded Square (Default)", "Circle", "Squircle",
                "Teardrop", "Hexagon", "System"
            });
            iconShape.setEntryValues(new String[]{
                "rounded_square", "circle", "squircle",
                "teardrop", "hexagon", "system"
            });
        }

        // Icon size
        SeekBarPreference iconSize = (SeekBarPreference) findPreference("nexusui_icon_size");
        if (iconSize != null) {
            iconSize.setMax(100);
            iconSize.setValue(60); // dp
        }
    }

    // ── Status bar ────────────────────────────────────────────────────────────

    private void setupStatusBarSection() {
        ListPreference clockPos = (ListPreference) findPreference("nexusui_statusbar_clock");
        if (clockPos != null) {
            clockPos.setEntries(new String[]{"Left", "Center (Default)", "Right", "Hidden"});
            clockPos.setEntryValues(new String[]{"left", "center", "right", "hidden"});
            clockPos.setValue(
                SystemProperties.get("persist.sys.nexusui.statusbar_clock", "center"));
        }

        SwitchPreference showDate = (SwitchPreference) findPreference("nexusui_statusbar_date");
        if (showDate != null) showDate.setChecked(true);

        SwitchPreference showSpeed = (SwitchPreference) findPreference("nexusui_network_speed");
        if (showSpeed != null) {
            showSpeed.setChecked(
                SystemProperties.getBoolean("persist.sys.nexusui.network_speed", true));
        }

        SwitchPreference sentinelIcon = (SwitchPreference) findPreference("nexusui_sentinel_icon");
        if (sentinelIcon != null) sentinelIcon.setChecked(true);
    }

    // ── Lock screen ───────────────────────────────────────────────────────────

    private void setupLockScreenSection() {
        SwitchPreference aod = (SwitchPreference) findPreference("nexusui_aod");
        if (aod != null) {
            aod.setChecked(
                SystemProperties.getBoolean("persist.sys.nexusui.aod_enabled", true));
        }

        ListPreference clockStyle = (ListPreference) findPreference("nexusui_lock_clock_style");
        if (clockStyle != null) {
            clockStyle.setEntries(new String[]{
                "Nexus Large (Default)", "Nexus Minimal", "Digital Bold",
                "Analog", "World Clock", "MIUI Style"
            });
        }

        SwitchPreference blurWallpaper = (SwitchPreference) findPreference("nexusui_lock_blur");
        if (blurWallpaper != null) blurWallpaper.setChecked(true);

        SwitchPreference mediaCard = (SwitchPreference) findPreference("nexusui_lock_media");
        if (mediaCard != null) mediaCard.setChecked(true);
    }

    // ── Animations ────────────────────────────────────────────────────────────

    private void setupAnimationSection() {
        ListPreference animSpeed = (ListPreference) findPreference("nexusui_anim_speed");
        if (animSpeed != null) {
            animSpeed.setEntries(new String[]{
                "Slow", "Normal (Default)", "Fast", "Instant"
            });
            animSpeed.setEntryValues(new String[]{"1.5", "1.0", "0.5", "0.0"});
            animSpeed.setValue("1.0");
        }

        SwitchPreference springAnim = (SwitchPreference) findPreference("nexusui_spring_anim");
        if (springAnim != null) {
            springAnim.setChecked(
                SystemProperties.getBoolean("persist.sys.nexusui.spring_animations", true));
        }

        SwitchPreference appLaunchAnim = (SwitchPreference) findPreference("nexusui_app_launch_anim");
        if (appLaunchAnim != null) appLaunchAnim.setChecked(true);
    }

    // ── Display ───────────────────────────────────────────────────────────────

    private void setupDisplaySection() {
        // Refresh rate
        ListPreference refreshRate = (ListPreference) findPreference("nexusui_refresh_rate");
        if (refreshRate != null) {
            refreshRate.setEntries(new String[]{"60 Hz", "90 Hz", "120 Hz (Default)", "Auto"});
            refreshRate.setEntryValues(new String[]{"60", "90", "120", "0"});
            refreshRate.setValue("120");
        }

        // Color profile
        ListPreference colorProfile = (ListPreference) findPreference("nexusui_color_profile");
        if (colorProfile != null) {
            colorProfile.setEntries(new String[]{
                "Nexus Vivid (Default)", "Natural", "Cinema", "sRGB"
            });
        }
    }

    // ── Advanced ─────────────────────────────────────────────────────────────

    private void setupAdvancedSection() {
        Preference resetPref = findPreference("nexusui_reset");
        if (resetPref != null) {
            resetPref.setOnPreferenceClickListener(pref -> {
                new AlertDialog.Builder(getActivity())
                    .setTitle("Reset NexusUI")
                    .setMessage("Reset all NexusUI settings to defaults?")
                    .setPositiveButton("Reset", (d, w) -> resetNexusUI())
                    .setNegativeButton("Cancel", null)
                    .show();
                return true;
            });
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void applyTheme(String theme) {
        int nightMode;
        switch (theme) {
            case "light": nightMode = android.app.UiModeManager.MODE_NIGHT_NO; break;
            case "auto":  nightMode = android.app.UiModeManager.MODE_NIGHT_AUTO; break;
            default:      nightMode = android.app.UiModeManager.MODE_NIGHT_YES;
        }
        android.app.UiModeManager uim =
            getActivity().getSystemService(android.app.UiModeManager.class);
        if (uim != null) uim.setNightMode(nightMode);
    }

    private void showAccentColorPicker() {
        // Show color grid dialog with preset accent colors
        String[] names = ACCENT_NAMES;
        new AlertDialog.Builder(getActivity())
            .setTitle("Accent Color")
            .setItems(names, (d, which) -> {
                int color = ACCENT_VALUES[which];
                SystemProperties.set("persist.sys.nexusui.accent_color", String.valueOf(color));
                Toast.makeText(getActivity(),
                    names[which] + " accent applied", Toast.LENGTH_SHORT).show();
            })
            .show();
    }

    private String getAccentName(int color) {
        for (int i = 0; i < ACCENT_VALUES.length; i++) {
            if (ACCENT_VALUES[i] == color) return ACCENT_NAMES[i];
        }
        return String.format("#%06X", (0xFFFFFF & color));
    }

    private void resetNexusUI() {
        String[] props = {
            "persist.sys.nexusui.theme",
            "persist.sys.nexusui.accent_color",
            "persist.sys.nexusui.blur_enabled",
            "persist.sys.nexusui.blur_radius",
            "persist.sys.nexusui.corner_radius",
            "persist.sys.nexusui.font",
            "persist.sys.nexusui.statusbar_clock",
            "persist.sys.nexusui.spring_animations",
            "persist.sys.nexusui.aod_enabled",
        };
        for (String p : props) SystemProperties.set(p, "");
        Toast.makeText(getActivity(), "NexusUI reset to defaults", Toast.LENGTH_SHORT).show();
    }
}
