/*
 * packages/NexusRecovery/nexus_recovery_ui.cpp
 * NexusRecovery — KynetixOS Custom Recovery UI
 *
 * Features:
 *   - NexusUI dark theme (matching OS)
 *   - SentinelLab pre-recovery integrity scan
 *   - Touch-enabled menus with NexusUI styling
 *   - Full partition wipe / flash / backup
 *   - ADB sideload
 *   - Aurora Store cache wipe
 */

#include "nexus_recovery_ui.h"
#include <android-base/logging.h>
#include <android-base/properties.h>

// ── Color palette (matches NexusUI) ─────────────────────────────────────────
static const Color NEXUS_BG         = {10,  10,  15,  255};  // #0A0A0F
static const Color NEXUS_SURFACE    = {30,  30,  46,  255};  // #1E1E2E
static const Color NEXUS_PRIMARY    = {41,  121, 255, 255};  // #2979FF
static const Color NEXUS_ACCENT     = {0,   229, 255, 255};  // #00E5FF
static const Color NEXUS_TEXT       = {255, 255, 255, 255};  // #FFFFFF
static const Color NEXUS_TEXT_DIM   = {179, 179, 255, 128};  // #B3B3FF80
static const Color NEXUS_SUCCESS    = {0,   200, 83,  255};  // #00C853
static const Color NEXUS_ERROR      = {255, 23,  68,  255};  // #FF1744
static const Color NEXUS_WARNING    = {255, 214, 0,   255};  // #FFD600
static const Color NEXUS_GOLD       = {255, 215, 0,   255};  // #FFD700
static const Color NEXUS_SEPARATOR  = {38,  38,  58,  255};  // #26263A

// ── Recovery header ──────────────────────────────────────────────────────────
void NexusRecoveryUI::SetBackground(Icon icon) {
    // Draw NexusUI-styled background
    DrawSurface(0, 0, gr_fb_width(), gr_fb_height(), NEXUS_BG);

    // Top header bar
    DrawSurface(0, 0, gr_fb_width(), 120, NEXUS_SURFACE);

    // "KynetixOS Recovery" title
    SetColor(NEXUS_TEXT);
    DrawTextBold("KynetixOS Recovery", gr_fb_width() / 2 - 160, 35, 36);

    // "NexusRecovery 1.0" subtitle
    SetColor(NEXUS_TEXT_DIM);
    DrawText("NexusRecovery 1.0 — Secured by Nexus", gr_fb_width() / 2 - 200, 80, 24);

    // Accent line below header
    DrawSurface(0, 118, gr_fb_width(), 2, NEXUS_PRIMARY);

    // SentinelLab badge (top-right)
    DrawSentinelBadge(gr_fb_width() - 180, 20);
}

// ── SentinelLab badge ────────────────────────────────────────────────────────
void NexusRecoveryUI::DrawSentinelBadge(int x, int y) {
    // Small shield badge in top corner
    DrawRoundRect(x, y, 160, 56, 12, NEXUS_PRIMARY);
    SetColor(NEXUS_TEXT);
    DrawText("🛡 SentinelLab", x + 8, y + 16, 20);
    DrawText("Secured by Nexus", x + 8, y + 36, 14);
}

// ── Menu item rendering ───────────────────────────────────────────────────────
void NexusRecoveryUI::DrawMenuItem(int index, const std::string& title,
                                    const std::string& subtitle,
                                    bool selected) {
    int y = HEADER_HEIGHT + MENU_PADDING + index * MENU_ITEM_HEIGHT;
    int x = MENU_PADDING;
    int w = gr_fb_width() - (MENU_PADDING * 2);

    // Item background
    Color bg = selected ? NEXUS_PRIMARY : NEXUS_SURFACE;
    DrawRoundRect(x, y, w, MENU_ITEM_HEIGHT - 8, 16, bg);

    // Selection indicator
    if (selected) {
        DrawSurface(x, y + 8, 4, MENU_ITEM_HEIGHT - 24, NEXUS_ACCENT);
    }

    // Title
    SetColor(NEXUS_TEXT);
    DrawTextBold(title, x + 24, y + 14, 28);

    // Subtitle
    SetColor(selected ? NEXUS_ACCENT : NEXUS_TEXT_DIM);
    DrawText(subtitle, x + 24, y + 48, 20);

    // Separator line
    if (!selected) {
        DrawSurface(x + 16, y + MENU_ITEM_HEIGHT - 9, w - 32, 1, NEXUS_SEPARATOR);
    }
}

// ── Main menu items ───────────────────────────────────────────────────────────
const std::vector<NexusMenuItem> NexusRecoveryUI::GetMainMenuItems() {
    return {
        {"Install",        "Flash ZIP / OTA package",            ICON_INSTALL},
        {"Wipe",           "Factory reset / partition wipe",     ICON_WIPE},
        {"Backup",         "NANDroid backup & restore",          ICON_BACKUP},
        {"Mount",          "Mount / unmount partitions",         ICON_MOUNT},
        {"Advanced",       "ADB, terminal, logs, settings",      ICON_ADVANCED},
        {"SentinelLab",    "Run security scan in recovery",      ICON_SENTINEL},
        {"Reboot",         "Reboot system / bootloader / EDL",   ICON_REBOOT},
    };
}

// ── Wipe submenu ─────────────────────────────────────────────────────────────
const std::vector<NexusMenuItem> NexusRecoveryUI::GetWipeMenuItems() {
    return {
        {"Factory Reset",       "Wipe data + cache (keep media)",        ICON_WIPE},
        {"Wipe Data",           "Full /data partition wipe",              ICON_WIPE},
        {"Wipe Cache",          "Clear system cache",                     ICON_WIPE},
        {"Wipe Dalvik / ART",   "Clear compiled app cache",               ICON_WIPE},
        {"Wipe System",         "⚠ Wipe /system partition",              ICON_WARN},
        {"Wipe Vendor",         "⚠ Wipe /vendor partition",              ICON_WARN},
        {"Format Data",         "⚠ Full format (removes encryption)",    ICON_WARN},
        {"Aurora Store Cache",  "Clear Aurora Store app cache",           ICON_WIPE},
        {"← Back",             "",                                        ICON_BACK},
    };
}

// ── Reboot submenu ────────────────────────────────────────────────────────────
const std::vector<NexusMenuItem> NexusRecoveryUI::GetRebootMenuItems() {
    return {
        {"Reboot System",       "Boot into KynetixOS",          ICON_REBOOT},
        {"Reboot Recovery",     "Restart NexusRecovery",         ICON_RECOVERY},
        {"Reboot Bootloader",   "Fastboot / flash mode",         ICON_FASTBOOT},
        {"Reboot EDL",          "Emergency Download Mode",       ICON_EDL},
        {"Power Off",           "Shut down device",              ICON_POWER},
        {"← Back",             "",                               ICON_BACK},
    };
}

// ── SentinelLab recovery scan ─────────────────────────────────────────────────
void NexusRecoveryUI::RunSentinelScan() {
    SetBackground(BACKGROUND_NONE);

    // Draw scan UI
    DrawSurface(0, 0, gr_fb_width(), gr_fb_height(), NEXUS_BG);
    DrawSentinelBadge(gr_fb_width() / 2 - 80, 80);

    SetColor(NEXUS_TEXT);
    DrawTextBold("SentinelLab Recovery Scan", gr_fb_width() / 2 - 200, 200, 32);

    SetColor(NEXUS_TEXT_DIM);
    DrawText("Hardware Permission Level 3", gr_fb_width() / 2 - 140, 250, 22);

    // Run phases
    const char* phases[] = {
        "Scanning hardware integrity...",
        "Verifying boot partitions...",
        "Checking dm-verity status...",
        "Scanning system partition...",
        "Verifying vendor partition...",
        "Checking for rootkits...",
        nullptr
    };

    int y = 340;
    for (int i = 0; phases[i] != nullptr; i++) {
        SetColor(NEXUS_PRIMARY);
        DrawText("  ◉  ", 80, y, 22);
        SetColor(NEXUS_TEXT);
        DrawText(phases[i], 140, y, 22);

        // Simulate scan progress (in real code: actual scan)
        usleep(400000);

        // Replace spinner with checkmark
        SetColor(NEXUS_SUCCESS);
        DrawText("  ✓  ", 80, y, 22);
        y += 50;
    }

    // Result
    DrawRoundRect(80, y + 20, gr_fb_width() - 160, 80, 16, NEXUS_SUCCESS);
    SetColor(NEXUS_BG);
    DrawTextBold("✓ System Integrity Verified — Secured by Nexus", 100, y + 38, 24);

    sleep(2);
}

// ── Progress bar (for flashing) ───────────────────────────────────────────────
void NexusRecoveryUI::SetProgress(float fraction) {
    int bar_x = 60;
    int bar_y = gr_fb_height() - 120;
    int bar_w = gr_fb_width() - 120;
    int bar_h = 8;

    // Track
    DrawRoundRect(bar_x, bar_y, bar_w, bar_h, 4, NEXUS_SURFACE);
    // Fill
    int filled = (int)(bar_w * fraction);
    DrawRoundRect(bar_x, bar_y, filled, bar_h, 4, NEXUS_PRIMARY);

    // Percentage label
    char pct[8];
    snprintf(pct, sizeof(pct), "%d%%", (int)(fraction * 100));
    SetColor(NEXUS_TEXT);
    DrawTextBold(pct, gr_fb_width() / 2 - 20, bar_y - 40, 28);
}

// ── Print (console output) ────────────────────────────────────────────────────
void NexusRecoveryUI::Print(const char* fmt, ...) {
    // Styled console output with NexusUI colors
    // [SentinelLab] messages in blue, errors in red, success in green
    va_list args;
    va_start(args, fmt);
    char buf[1024];
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    Color c = NEXUS_TEXT;
    if (strstr(buf, "SentinelLab") || strstr(buf, "Sentinel"))
        c = NEXUS_PRIMARY;
    else if (strstr(buf, "Error") || strstr(buf, "Failed") || strstr(buf, "failed"))
        c = NEXUS_ERROR;
    else if (strstr(buf, "Success") || strstr(buf, "Complete") || strstr(buf, "Done"))
        c = NEXUS_SUCCESS;
    else if (strstr(buf, "Warning") || strstr(buf, "Warn"))
        c = NEXUS_WARNING;

    SetColor(c);
    DrawTextConsole(buf);
}
