#
# packages/NexusRecovery/Android.mk
# NexusRecovery — KynetixOS Custom Recovery
# Based on TWRP/LineageOS Recovery with NexusUI design
#

LOCAL_PATH := $(call my-dir)

# ── Recovery UI library ──────────────────────────────────────────────────────
include $(CLEAR_VARS)
LOCAL_MODULE := librecovery_ui_kynetix
LOCAL_MODULE_TAGS := optional
LOCAL_SRC_FILES := \
    nexus_recovery_ui.cpp \
    nexus_recovery_ui_touch.cpp \
    nexus_recovery_themes.cpp \
    SentinelLabRecovery.cpp

LOCAL_C_INCLUDES += \
    bootable/recovery \
    bootable/recovery/recovery_ui/include

LOCAL_SHARED_LIBS := \
    libbase \
    libcutils \
    liblog \
    librecovery_ui

LOCAL_STATIC_LIBS := \
    libminui \
    libfusesideload

include $(BUILD_STATIC_LIBRARY)

# ── Recovery binary ──────────────────────────────────────────────────────────
include $(CLEAR_VARS)
LOCAL_MODULE := recovery
LOCAL_SRC_FILES := nexus_recovery_main.cpp
LOCAL_WHOLE_STATIC_LIBRARIES := librecovery_ui_kynetix
LOCAL_SHARED_LIBS := libbase liblog libcutils
include $(BUILD_EXECUTABLE)
