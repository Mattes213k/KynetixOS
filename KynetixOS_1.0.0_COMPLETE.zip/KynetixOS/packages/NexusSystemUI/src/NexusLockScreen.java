/*
 * packages/NexusSystemUI/src/com/kynetix/systemui/NexusLockScreen.java
 * NexusUI Lockscreen — KynetixOS 1.0
 *
 * Features:
 *   - Large clock (Nexus Display font)
 *   - Date + weather summary
 *   - SentinelLab "Secured by Nexus" badge
 *   - AOD (Always-On Display) support
 *   - Blur wallpaper behind lockscreen
 *   - Biometric unlock (fingerprint side-button)
 *   - Swipe-up to unlock / PIN/pattern fallback
 *   - Notification previews (NexusUI card style)
 *   - Media player card on lock screen
 *   - Quick shortcuts: camera, flashlight
 */

package com.kynetix.systemui;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.os.SystemProperties;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

public class NexusLockScreen extends FrameLayout {

    // Views
    private TextView    mClockHour;
    private TextView    mClockMinute;
    private TextView    mDateText;
    private TextView    mWeatherText;
    private View        mSentinelBadge;
    private TextView    mSentinelLabel;
    private ImageView   mSentinelIcon;
    private LinearLayout mNotifStack;
    private View        mMediaCard;
    private ImageView   mFingerprintHint;
    private View        mUnlockArrow;
    private View        mCameraShortcut;
    private View        mFlashShortcut;
    private View        mAodLayer;        // Always-On Display overlay

    // State
    private boolean     mAodEnabled;
    private boolean     mLocked = true;
    private float       mSwipeStartY;
    private static final float UNLOCK_THRESHOLD = 0.35f; // 35% of screen

    public NexusLockScreen(Context ctx) {
        super(ctx);
        init(ctx);
    }

    private void init(Context ctx) {
        LayoutInflater.from(ctx).inflate(R.layout.nexus_lockscreen, this, true);

        mClockHour      = findViewById(R.id.lock_clock_hour);
        mClockMinute    = findViewById(R.id.lock_clock_minute);
        mDateText       = findViewById(R.id.lock_date);
        mWeatherText    = findViewById(R.id.lock_weather);
        mSentinelBadge  = findViewById(R.id.lock_sentinel_badge);
        mSentinelLabel  = findViewById(R.id.lock_sentinel_label);
        mSentinelIcon   = findViewById(R.id.lock_sentinel_icon);
        mNotifStack     = findViewById(R.id.lock_notif_stack);
        mMediaCard      = findViewById(R.id.lock_media_card);
        mFingerprintHint = findViewById(R.id.lock_fp_hint);
        mUnlockArrow    = findViewById(R.id.lock_unlock_arrow);
        mCameraShortcut = findViewById(R.id.lock_shortcut_camera);
        mFlashShortcut  = findViewById(R.id.lock_shortcut_flash);
        mAodLayer       = findViewById(R.id.lock_aod_layer);

        mAodEnabled = SystemProperties.getBoolean("persist.sys.nexusui.aod_enabled", true);

        setupClock();
        setupSentinelBadge();
        setupShortcuts();
        setupSwipeUnlock();

        if (mAodEnabled) setupAod();
    }

    // ── Clock ─────────────────────────────────────────────────────────────────

    private void setupClock() {
        updateClock();
        postDelayed(new Runnable() {
            @Override public void run() {
                updateClock();
                postDelayed(this, 30_000); // Update every 30s
            }
        }, 30_000);
    }

    private void updateClock() {
        Calendar cal = Calendar.getInstance();
        boolean is24h = android.text.format.DateFormat.is24HourFormat(getContext());
        int hour = cal.get(is24h ? Calendar.HOUR_OF_DAY : Calendar.HOUR);
        int min  = cal.get(Calendar.MINUTE);
        if (!is24h && hour == 0) hour = 12;

        // NexusUI lockscreen: split hour/minute for large clock layout
        mClockHour.setText(String.valueOf(hour));
        mClockMinute.setText(String.format(java.util.Locale.getDefault(), "%02d", min));

        // Date
        String date = (String) android.text.format.DateFormat.format("EEEE, MMMM d", cal);
        mDateText.setText(date);
    }

    // ── SentinelLab badge ─────────────────────────────────────────────────────

    private void setupSentinelBadge() {
        boolean clean  = SystemProperties.getBoolean("ro.sentinellab.boot_clean", false);
        boolean threat = SystemProperties.getBoolean("sentinellab.threat_detected", false);

        if (threat) {
            mSentinelLabel.setText("⚠ Threat Detected");
            mSentinelLabel.setTextColor(0xFFFF1744);
            mSentinelIcon.setImageResource(R.drawable.ic_sentinel_threat);
            mSentinelBadge.setBackgroundResource(R.drawable.nexus_badge_threat);
            // Pulse animation
            ObjectAnimator pulse = ObjectAnimator.ofFloat(mSentinelBadge, "alpha", 1f, 0.5f);
            pulse.setDuration(700);
            pulse.setRepeatMode(ObjectAnimator.REVERSE);
            pulse.setRepeatCount(ObjectAnimator.INFINITE);
            pulse.start();
        } else if (clean) {
            mSentinelLabel.setText("Secured by Nexus");
            mSentinelLabel.setTextColor(0xFF00C853);
            mSentinelIcon.setImageResource(R.drawable.ic_sentinel_shield);
            mSentinelBadge.setBackgroundResource(R.drawable.nexus_badge_secure);
        } else {
            mSentinelLabel.setText("SentinelLab");
            mSentinelLabel.setTextColor(0xFFFFFFFF);
            mSentinelIcon.setImageResource(R.drawable.ic_sentinel_shield);
            mSentinelBadge.setBackgroundResource(R.drawable.nexus_badge_default);
        }

        // Entrance animation
        mSentinelBadge.setAlpha(0f);
        mSentinelBadge.setTranslationY(20f);
        mSentinelBadge.animate()
            .alpha(1f).translationY(0f)
            .setStartDelay(400)
            .setDuration(500)
            .setInterpolator(new OvershootInterpolator(1.2f))
            .start();
    }

    // ── Shortcuts ─────────────────────────────────────────────────────────────

    private void setupShortcuts() {
        // Camera shortcut (bottom-right)
        mCameraShortcut.setOnClickListener(v -> {
            Intent intent = new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        });

        // Flashlight shortcut (bottom-left)
        mFlashShortcut.setOnClickListener(v -> {
            toggleFlashlight();
        });
    }

    // ── Swipe to unlock ───────────────────────────────────────────────────────

    private void setupSwipeUnlock() {
        setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    mSwipeStartY = event.getY();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dy = mSwipeStartY - event.getY();
                    float progress = Math.min(1f, dy / (getHeight() * UNLOCK_THRESHOLD));
                    if (progress > 0) {
                        // Translate lockscreen up
                        setTranslationY(-dy * 0.6f);
                        setAlpha(1f - progress * 0.5f);
                        // Show unlock hint
                        mUnlockArrow.setAlpha(progress);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    float totalDy = mSwipeStartY - event.getY();
                    if (totalDy > getHeight() * UNLOCK_THRESHOLD) {
                        triggerUnlock();
                    } else {
                        // Snap back
                        animate().translationY(0f).alpha(1f)
                            .setDuration(200)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();
                    }
                    return true;
            }
            return false;
        });
    }

    private void triggerUnlock() {
        // Check biometric (fingerprint already handled by side button in HW)
        // This is the fallback swipe-unlock UI
        animate()
            .translationY(-getHeight())
            .alpha(0f)
            .setDuration(280)
            .setInterpolator(new DecelerateInterpolator(2f))
            .withEndAction(() -> {
                mLocked = false;
                setVisibility(GONE);
                // Notify SystemUI to unlock
                getContext().sendBroadcast(
                    new Intent("com.kynetix.systemui.UNLOCK"));
            })
            .start();
    }

    // ── AOD (Always-On Display) ───────────────────────────────────────────────

    private void setupAod() {
        // AOD layer: minimal clock + date + sentinel badge on dark bg
        // Shown when screen is off but AMOLED pixels are on
        mAodLayer.setVisibility(GONE);
        // In production: show mAodLayer when display enters doze state
        // Triggered by DreamManager / DisplayManager doze callbacks
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void toggleFlashlight() {
        android.hardware.camera2.CameraManager cm =
            getContext().getSystemService(android.hardware.camera2.CameraManager.class);
        try {
            if (cm != null) {
                String[] ids = cm.getCameraIdList();
                if (ids.length > 0) cm.setTorchMode(ids[0], true);
            }
        } catch (Exception ignored) {}
    }
}
