/*
 * packages/NexusSystemUI/src/com/kynetix/systemui/NexusStatusBar.java
 * NexusUI SystemUI — Status Bar Controller
 * KynetixOS 1.0
 *
 * Features:
 *   - Center clock with date
 *   - SentinelLab shield icon (live status)
 *   - Transparent/blur background
 *   - Battery percentage + custom icon
 *   - Network speed indicator
 *   - NexusUI notification dot style
 */

package com.kynetix.systemui;

import android.animation.ObjectAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemProperties;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

public class NexusStatusBar extends LinearLayout {

    private static final String TAG = "NexusStatusBar";

    // Views
    private TextView    mClockView;
    private TextView    mDateView;
    private TextView    mBatteryText;
    private ImageView   mBatteryIcon;
    private ImageView   mSentinelIcon;
    private TextView    mNetworkSpeed;
    private LinearLayout mLeftSlot;
    private LinearLayout mCenterSlot;
    private LinearLayout mRightSlot;

    // State
    private Handler     mHandler;
    private boolean     mSentinelSecure = true;
    private int         mBatteryLevel   = 100;
    private boolean     mCharging       = false;

    // Colors
    private static final int COLOR_TEXT      = 0xFFFFFFFF;
    private static final int COLOR_TEXT_DIM  = 0xB3FFFFFF;
    private static final int COLOR_SENTINEL_OK     = 0xFF00C853;
    private static final int COLOR_SENTINEL_WARN   = 0xFFFFD600;
    private static final int COLOR_SENTINEL_THREAT = 0xFFFF1744;
    private static final int COLOR_PRIMARY   = 0xFF2979FF;

    public NexusStatusBar(Context context) { this(context, null); }
    public NexusStatusBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context ctx) {
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setBackgroundColor(Color.TRANSPARENT);

        LayoutInflater.from(ctx).inflate(R.layout.nexus_status_bar, this, true);

        mClockView    = findViewById(R.id.status_clock);
        mDateView     = findViewById(R.id.status_date);
        mBatteryText  = findViewById(R.id.status_battery_text);
        mBatteryIcon  = findViewById(R.id.status_battery_icon);
        mSentinelIcon = findViewById(R.id.status_sentinel_icon);
        mNetworkSpeed = findViewById(R.id.status_network_speed);
        mLeftSlot     = findViewById(R.id.status_left);
        mCenterSlot   = findViewById(R.id.status_center);
        mRightSlot    = findViewById(R.id.status_right);

        mHandler = new Handler(Looper.getMainLooper());

        setupClock();
        setupBattery(ctx);
        setupSentinel();
        setupNetworkSpeed();
    }

    // ── Clock (center) ────────────────────────────────────────────────────────

    private void setupClock() {
        updateClock();
        // Tick every second
        mHandler.post(new Runnable() {
            @Override public void run() {
                updateClock();
                mHandler.postDelayed(this, 1000);
            }
        });
    }

    private void updateClock() {
        Calendar cal = Calendar.getInstance();
        boolean is24h = DateFormat.is24HourFormat(getContext());

        int hour   = cal.get(is24h ? Calendar.HOUR_OF_DAY : Calendar.HOUR);
        int minute = cal.get(Calendar.MINUTE);
        if (!is24h && hour == 0) hour = 12;

        // NexusUI clock style: bold hour, thin colon+minute
        String time = String.format(java.util.Locale.getDefault(),
            "%d:%02d", hour, minute);
        mClockView.setText(time);

        // Date below clock on lock screen / condensed in status bar
        String date = (String) DateFormat.format("EEE, MMM d", cal);
        mDateView.setText(date);
    }

    // ── Battery ───────────────────────────────────────────────────────────────

    private void setupBattery(Context ctx) {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        ctx.registerReceiver(new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent intent) {
                mBatteryLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100);
                mCharging     = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                                == BatteryManager.BATTERY_STATUS_CHARGING;
                updateBattery();
            }
        }, filter);
    }

    private void updateBattery() {
        mBatteryText.setText(mBatteryLevel + "%");

        // Color: green > 20%, yellow 10-20%, red < 10%
        int color;
        if (mBatteryLevel > 20)      color = COLOR_TEXT;
        else if (mBatteryLevel > 10) color = COLOR_SENTINEL_WARN;
        else                         color = COLOR_SENTINEL_THREAT;

        mBatteryText.setTextColor(color);

        // Icon resource based on level
        int iconRes = getBatteryIconRes(mBatteryLevel, mCharging);
        mBatteryIcon.setImageResource(iconRes);
    }

    private int getBatteryIconRes(int level, boolean charging) {
        if (charging) return R.drawable.ic_battery_charging;
        if (level >= 90) return R.drawable.ic_battery_full;
        if (level >= 60) return R.drawable.ic_battery_75;
        if (level >= 35) return R.drawable.ic_battery_50;
        if (level >= 15) return R.drawable.ic_battery_25;
        return R.drawable.ic_battery_low;
    }

    // ── SentinelLab icon ──────────────────────────────────────────────────────

    private void setupSentinel() {
        refreshSentinelStatus();
        // Refresh every 30 seconds
        mHandler.postDelayed(new Runnable() {
            @Override public void run() {
                refreshSentinelStatus();
                mHandler.postDelayed(this, 30_000);
            }
        }, 30_000);

        // Click → open SentinelLab
        mSentinelIcon.setOnClickListener(v -> {
            Intent intent = new Intent("com.kynetix.sentinellab.UI");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        });
    }

    public void refreshSentinelStatus() {
        boolean clean  = SystemProperties.getBoolean("ro.sentinellab.boot_clean", false);
        boolean threat = SystemProperties.getBoolean("sentinellab.threat_detected", false);

        int color;
        int iconRes;
        if (threat) {
            color   = COLOR_SENTINEL_THREAT;
            iconRes = R.drawable.ic_sentinel_threat;
        } else if (clean) {
            color   = COLOR_SENTINEL_OK;
            iconRes = R.drawable.ic_sentinel_shield;
        } else {
            color   = COLOR_SENTINEL_WARN;
            iconRes = R.drawable.ic_sentinel_warning;
        }

        mSentinelIcon.setImageResource(iconRes);
        mSentinelIcon.setColorFilter(color);

        // Pulse animation on threat
        if (threat) {
            ObjectAnimator pulse = ObjectAnimator.ofFloat(mSentinelIcon, "alpha", 1f, 0.3f);
            pulse.setDuration(600);
            pulse.setRepeatMode(ObjectAnimator.REVERSE);
            pulse.setRepeatCount(ObjectAnimator.INFINITE);
            pulse.start();
        }
    }

    // ── Network speed ──────────────────────────────────────────────────────────

    private void setupNetworkSpeed() {
        boolean showSpeed = SystemProperties.getBoolean("persist.sys.nexusui.network_speed", true);
        mNetworkSpeed.setVisibility(showSpeed ? VISIBLE : GONE);

        mHandler.post(new Runnable() {
            long prevRx = 0, prevTx = 0;
            @Override public void run() {
                if (!showSpeed) return;
                try {
                    long rx = readNetStat("rx_bytes");
                    long tx = readNetStat("tx_bytes");
                    long speed = (rx - prevRx + tx - prevTx); // bytes/sec
                    prevRx = rx; prevTx = tx;
                    mNetworkSpeed.setText(formatSpeed(speed));
                } catch (Exception ignored) {}
                mHandler.postDelayed(this, 1000);
            }
        });
    }

    private long readNetStat(String stat) throws Exception {
        java.io.File f = new java.io.File("/proc/net/dev");
        // In production: parse /proc/net/dev for all interfaces
        return 0;
    }

    private String formatSpeed(long bytesPerSec) {
        if (bytesPerSec < 1024)          return bytesPerSec + " B/s";
        if (bytesPerSec < 1024 * 1024)   return (bytesPerSec / 1024) + " KB/s";
        return String.format("%.1f MB/s", bytesPerSec / (1024.0 * 1024));
    }
}
