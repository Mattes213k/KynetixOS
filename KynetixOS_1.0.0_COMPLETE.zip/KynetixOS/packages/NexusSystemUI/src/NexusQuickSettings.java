/*
 * packages/NexusSystemUI/src/com/kynetix/systemui/NexusQuickSettings.java
 * NexusUI Quick Settings Panel — KynetixOS 1.0
 *
 * Features:
 *   - 4-column grid with NexusUI tile style
 *   - Blur + glass background (#CC0A0A0F)
 *   - Brightness slider (pill style)
 *   - SentinelLab tile (live status, tap to scan)
 *   - Media player card
 *   - User account + device name header
 *   - NexusUI rounded tiles (20dp corner radius)
 */

package com.kynetix.systemui;

import android.content.Context;
import android.graphics.Color;
import android.os.SystemProperties;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class NexusQuickSettings extends LinearLayout {

    // Tile IDs
    public static final String TILE_WIFI        = "wifi";
    public static final String TILE_BLUETOOTH   = "bluetooth";
    public static final String TILE_MOBILE_DATA = "cell";
    public static final String TILE_AIRPLANE    = "airplane";
    public static final String TILE_LOCATION    = "location";
    public static final String TILE_ROTATION    = "rotation";
    public static final String TILE_DND         = "dnd";
    public static final String TILE_FLASHLIGHT  = "flashlight";
    public static final String TILE_HOTSPOT     = "hotspot";
    public static final String TILE_BATTERY     = "battery";
    public static final String TILE_DARK_MODE   = "dark_mode";
    public static final String TILE_SENTINEL    = "sentinellab";
    public static final String TILE_NEXUSUI     = "nexusui";
    public static final String TILE_AURORA      = "aurora_store";
    public static final String TILE_SCREENREC   = "screenrecord";
    public static final String TILE_NFC         = "nfc";

    // Default tile order
    private static final String[] DEFAULT_TILES = {
        TILE_WIFI, TILE_BLUETOOTH, TILE_MOBILE_DATA, TILE_AIRPLANE,
        TILE_LOCATION, TILE_ROTATION, TILE_DND, TILE_FLASHLIGHT,
        TILE_SENTINEL, TILE_DARK_MODE, TILE_HOTSPOT, TILE_BATTERY,
        TILE_AURORA, TILE_SCREENREC, TILE_NFC, TILE_NEXUSUI
    };

    private GridLayout      mTileGrid;
    private NexusBrightnessSlider mBrightnessSlider;
    private NexusMediaCard  mMediaCard;
    private TextView        mDeviceLabel;
    private TextView        mUserLabel;
    private List<NexusQSTile> mTiles = new ArrayList<>();

    public NexusQuickSettings(Context ctx) {
        super(ctx);
        init(ctx);
    }

    private void init(Context ctx) {
        setOrientation(VERTICAL);
        setBackgroundColor(0xCC0A0A0F); // Frosted dark

        LayoutInflater.from(ctx).inflate(R.layout.nexus_quick_settings, this, true);

        mTileGrid        = findViewById(R.id.qs_tile_grid);
        mBrightnessSlider = findViewById(R.id.qs_brightness_slider);
        mMediaCard       = findViewById(R.id.qs_media_card);
        mDeviceLabel     = findViewById(R.id.qs_device_label);
        mUserLabel       = findViewById(R.id.qs_user_label);

        setupHeader();
        setupBrightnessSlider();
        setupTiles(ctx);
        setupMediaCard();
    }

    // ── Header ────────────────────────────────────────────────────────────────

    private void setupHeader() {
        mDeviceLabel.setText("Redmi Note 13 Pro");
        mDeviceLabel.setTextColor(0xFFFFFFFF);

        String user = SystemProperties.get("persist.sys.kynetix.username", "Nexus User");
        mUserLabel.setText(user);
        mUserLabel.setTextColor(0xB3FFFFFF);
    }

    // ── Brightness ────────────────────────────────────────────────────────────

    private void setupBrightnessSlider() {
        mBrightnessSlider.setCornerRadius(dpToPx(8));
        mBrightnessSlider.setActiveColor(0xFF2979FF);
        mBrightnessSlider.setTrackColor(0x1E1E2E);
        mBrightnessSlider.setOnBrightnessChangeListener(brightness -> {
            android.provider.Settings.System.putInt(
                getContext().getContentResolver(),
                android.provider.Settings.System.SCREEN_BRIGHTNESS,
                brightness);
        });
    }

    // ── Tiles ──────────────────────────────────────────────────────────────────

    private void setupTiles(Context ctx) {
        mTileGrid.setColumnCount(4);
        mTileGrid.setRowCount(4);

        for (String tileId : DEFAULT_TILES) {
            NexusQSTile tile = createTile(ctx, tileId);
            mTiles.add(tile);
            mTileGrid.addView(tile);
        }
    }

    private NexusQSTile createTile(Context ctx, String id) {
        NexusQSTile tile = new NexusQSTile(ctx);
        tile.setCornerRadius(dpToPx(20));
        tile.setTileId(id);

        switch (id) {
            case TILE_WIFI:
                tile.setIcon(R.drawable.ic_qs_wifi);
                tile.setLabel("Wi-Fi");
                tile.setOnClickListener(v -> toggleWifi());
                tile.setOnLongClickListener(v -> {
                    openSettings("android.settings.WIFI_SETTINGS"); return true;
                });
                break;

            case TILE_BLUETOOTH:
                tile.setIcon(R.drawable.ic_qs_bluetooth);
                tile.setLabel("Bluetooth");
                tile.setOnClickListener(v -> toggleBluetooth());
                tile.setOnLongClickListener(v -> {
                    openSettings("android.settings.BLUETOOTH_SETTINGS"); return true;
                });
                break;

            case TILE_MOBILE_DATA:
                tile.setIcon(R.drawable.ic_qs_data);
                tile.setLabel("Mobile Data");
                tile.setOnClickListener(v -> toggleMobileData());
                break;

            case TILE_AIRPLANE:
                tile.setIcon(R.drawable.ic_qs_airplane);
                tile.setLabel("Airplane");
                tile.setOnClickListener(v -> toggleAirplaneMode());
                break;

            case TILE_LOCATION:
                tile.setIcon(R.drawable.ic_qs_location);
                tile.setLabel("Location");
                tile.setOnClickListener(v -> toggleLocation());
                break;

            case TILE_ROTATION:
                tile.setIcon(R.drawable.ic_qs_rotation);
                tile.setLabel("Auto-rotate");
                tile.setOnClickListener(v -> toggleAutoRotate());
                break;

            case TILE_DND:
                tile.setIcon(R.drawable.ic_qs_dnd);
                tile.setLabel("Do Not Disturb");
                tile.setOnClickListener(v -> toggleDnD());
                break;

            case TILE_FLASHLIGHT:
                tile.setIcon(R.drawable.ic_qs_flashlight);
                tile.setLabel("Flashlight");
                tile.setOnClickListener(v -> toggleFlashlight());
                break;

            case TILE_SENTINEL:
                // SentinelLab tile — shows live security status
                setupSentinelTile(tile);
                break;

            case TILE_DARK_MODE:
                tile.setIcon(R.drawable.ic_qs_dark_mode);
                tile.setLabel("Dark Mode");
                tile.setActive(true); // Always on in KynetixOS
                tile.setOnClickListener(v -> toggleDarkMode(tile));
                break;

            case TILE_HOTSPOT:
                tile.setIcon(R.drawable.ic_qs_hotspot);
                tile.setLabel("Hotspot");
                tile.setOnClickListener(v -> toggleHotspot());
                break;

            case TILE_BATTERY:
                tile.setIcon(R.drawable.ic_qs_battery_saver);
                tile.setLabel("Battery Saver");
                tile.setOnClickListener(v -> toggleBatterySaver(tile));
                break;

            case TILE_AURORA:
                tile.setIcon(R.drawable.ic_aurora_store);
                tile.setLabel("Aurora Store");
                tile.setOnClickListener(v -> launchApp("com.aurora.store"));
                break;

            case TILE_SCREENREC:
                tile.setIcon(R.drawable.ic_qs_screenrecord);
                tile.setLabel("Record");
                tile.setOnClickListener(v -> startScreenRecord());
                break;

            case TILE_NFC:
                tile.setIcon(R.drawable.ic_qs_nfc);
                tile.setLabel("NFC");
                tile.setOnClickListener(v -> toggleNfc(tile));
                break;

            case TILE_NEXUSUI:
                tile.setIcon(R.drawable.ic_nexusui_logo);
                tile.setLabel("NexusUI");
                tile.setOnClickListener(v -> openNexusUISettings());
                tile.setOnLongClickListener(v -> {
                    openSettings("com.kynetix.nexuslauncher.settings.NexusLauncherSettings");
                    return true;
                });
                break;
        }
        return tile;
    }

    // ── SentinelLab tile ──────────────────────────────────────────────────────

    private void setupSentinelTile(NexusQSTile tile) {
        boolean clean  = SystemProperties.getBoolean("ro.sentinellab.boot_clean", false);
        boolean threat = SystemProperties.getBoolean("sentinellab.threat_detected", false);

        tile.setIcon(R.drawable.ic_sentinel_shield);
        tile.setLabel("SentinelLab");

        if (threat) {
            tile.setSubLabel("Threat detected!");
            tile.setIconTint(0xFFFF1744);
            tile.setActive(false);
            tile.setBackgroundColor(0x33FF1744);
        } else if (clean) {
            tile.setSubLabel("Secured by Nexus");
            tile.setIconTint(0xFF00C853);
            tile.setActive(true);
        } else {
            tile.setSubLabel("Scanning...");
            tile.setIconTint(0xFF2979FF);
        }

        tile.setOnClickListener(v -> {
            launchApp("com.kynetix.nexusantivirus");
        });
        tile.setOnLongClickListener(v -> {
            // Trigger immediate scan
            Intent scan = new Intent("com.kynetix.sentinellab.SCAN_NOW");
            getContext().sendBroadcast(scan);
            tile.setSubLabel("Scanning...");
            return true;
        });
    }

    // ── Media card ────────────────────────────────────────────────────────────

    private void setupMediaCard() {
        mMediaCard.setCornerRadius(dpToPx(16));
        mMediaCard.setBackgroundColor(0x1E1E2E);
        mMediaCard.setVisibility(GONE); // Show only when music is playing
    }

    // ── Toggle helpers ────────────────────────────────────────────────────────

    private void toggleWifi() {
        android.net.wifi.WifiManager wm =
            (android.net.wifi.WifiManager) getContext()
                .getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (wm != null) wm.setWifiEnabled(!wm.isWifiEnabled());
    }

    private void toggleBluetooth() {
        android.bluetooth.BluetoothAdapter bt = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
        if (bt != null) {
            if (bt.isEnabled()) bt.disable(); else bt.enable();
        }
    }

    private void toggleMobileData() {
        // Requires MODIFY_PHONE_STATE permission (system app)
    }

    private void toggleAirplaneMode() {
        boolean current = android.provider.Settings.Global.getInt(
            getContext().getContentResolver(),
            android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
        android.provider.Settings.Global.putInt(
            getContext().getContentResolver(),
            android.provider.Settings.Global.AIRPLANE_MODE_ON, current ? 0 : 1);
        Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        intent.putExtra("state", !current);
        getContext().sendBroadcast(intent);
    }

    private void toggleLocation() {
        openSettings(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
    }

    private void toggleAutoRotate() {
        int current = android.provider.Settings.System.getInt(
            getContext().getContentResolver(),
            android.provider.Settings.System.ACCELEROMETER_ROTATION, 0);
        android.provider.Settings.System.putInt(
            getContext().getContentResolver(),
            android.provider.Settings.System.ACCELEROMETER_ROTATION,
            current == 1 ? 0 : 1);
    }

    private void toggleDnD() {
        android.app.NotificationManager nm =
            getContext().getSystemService(android.app.NotificationManager.class);
        if (nm != null) {
            if (nm.getCurrentInterruptionFilter() ==
                    android.app.NotificationManager.INTERRUPTION_FILTER_ALL) {
                nm.setInterruptionFilter(
                    android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            } else {
                nm.setInterruptionFilter(
                    android.app.NotificationManager.INTERRUPTION_FILTER_ALL);
            }
        }
    }

    private void toggleFlashlight() {
        android.hardware.camera2.CameraManager cm =
            getContext().getSystemService(android.hardware.camera2.CameraManager.class);
        try {
            if (cm != null) {
                String[] ids = cm.getCameraIdList();
                if (ids.length > 0) cm.setTorchMode(ids[0], true);
            }
        } catch (Exception e) { /* ignore */ }
    }

    private void toggleDarkMode(NexusQSTile tile) {
        android.app.UiModeManager uim =
            getContext().getSystemService(android.app.UiModeManager.class);
        if (uim != null) {
            int mode = uim.getNightMode();
            boolean isDark = mode == android.app.UiModeManager.MODE_NIGHT_YES;
            uim.setNightMode(isDark
                ? android.app.UiModeManager.MODE_NIGHT_NO
                : android.app.UiModeManager.MODE_NIGHT_YES);
            tile.setActive(!isDark);
        }
    }

    private void toggleHotspot() {
        openSettings("android.settings.TETHER_SETTINGS");
    }

    private void toggleBatterySaver(NexusQSTile tile) {
        android.os.PowerManager pm = getContext().getSystemService(android.os.PowerManager.class);
        if (pm != null) {
            boolean saver = pm.isPowerSaveMode();
            // Requires DEVICE_POWER permission
            android.provider.Settings.Global.putInt(
                getContext().getContentResolver(),
                "low_power", saver ? 0 : 1);
            tile.setActive(!saver);
        }
    }

    private void toggleNfc(NexusQSTile tile) {
        android.nfc.NfcAdapter nfc = android.nfc.NfcAdapter.getDefaultAdapter(getContext());
        if (nfc != null) {
            if (nfc.isEnabled()) { nfc.disable(); tile.setActive(false); }
            else { nfc.enable(); tile.setActive(true); }
        }
    }

    private void startScreenRecord() {
        Intent intent = new Intent("com.kynetix.systemui.SCREEN_RECORD");
        getContext().sendBroadcast(intent);
    }

    private void openNexusUISettings() {
        openSettings("com.kynetix.nexuslauncher.settings.NexusLauncherSettings");
    }

    private void openSettings(String action) {
        Intent intent = new Intent(action);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
    }

    private void launchApp(String packageName) {
        Intent intent = getContext().getPackageManager()
            .getLaunchIntentForPackage(packageName);
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        }
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
