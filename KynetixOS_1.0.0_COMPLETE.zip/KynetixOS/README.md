# KynetixOS 1.0 — Sapphire Edition

> **Android 15 custom ROM** for Xiaomi Redmi Note 13 Pro  
> NexusUI · SentinelLab · NexusAntivirus · NexusRecovery · Aurora Store

---

## What's inside this tree

```
KynetixOS/
├── device/xiaomi/sapphire/
│   ├── device.mk              ← Product definition
│   └── BoardConfig.mk         ← Hardware config (SM7435)
├── vendor/kynetix/
│   ├── config/kynetix.mk      ← Core OS config, properties
│   ├── overlay/
│   │   ├── nexusui.mk         ← NexusUI overlay entry
│   │   ├── framework/res/     ← Colors, styles, themes
│   │   ├── SystemUI/res/      ← Status bar, QS, lockscreen config
│   │   └── Settings/res/      ← Settings branding + KynetixOS panel
│   ├── security/sentinellab/
│   │   ├── sentinellab.mk     ← SentinelLab build config
│   │   ├── sentinellabd.cpp   ← Hardware scanner daemon (C++)
│   │   ├── Android.bp         ← Build rules
│   │   ├── sentinel_config.xml← Security policy config
│   │   ├── sepolicy/          ← SELinux policy
│   │   └── init/init.sentinel.rc ← Pre-boot init scripts
│   ├── apps/
│   │   ├── AuroraStore/       ← Aurora Store prebuilt + permissions
│   │   └── NexusAntivirus/    ← NexusAntivirus app
│   └── prebuilt/bootanimation/
│       ├── bootanimation.zip  ← ✅ REAL generated (159 frames)
│       ├── generate_bootanim.py ← Generator script
│       └── BOOTANIM_SPEC.txt  ← Frame-by-frame design spec
├── packages/NexusRecovery/
│   ├── Android.mk             ← Recovery build rules
│   └── nexus_recovery_ui.cpp  ← NexusUI recovery renderer
├── kernel/configs/
│   └── kynetix_defconfig      ← Kernel config (SentinelLab, dm-verity, IMA)
└── build/
    ├── tools/build_kynetix.sh ← Full automated build script
    └── target/kynetix_manifest.xml ← repo sync manifest
```

---

## Feature overview

### 🎨 NexusUI
- Dark-first design system (MIUI/OneUI inspired, completely original)
- Color: `#2979FF` primary, `#00E5FF` accent, `#0A0A0F` background
- Fonts: Nexus Display (custom)
- 24dp corner radius system-wide, 30px blur behind sheets
- Center clock in status bar
- NexusUI Settings panel with full OS controls

### 🛡 SentinelLab — Secured by Nexus
Hardware Permission Level 3:
1. **early-init** — hardware fuse check, secure boot verify, TEE (QSEE) handshake
2. **init** — dm-verity enforcement on system/vendor/product, IMA kernel measurement
3. **post-fs-data** — system partition integrity, signature DB match
4. **runtime** — realtime file system monitor, network firewall, process scanner
- Shows on boot splash: *"Secured by Nexus — SentinelLab Scanning..."*
- SELinux type enforcement with full HW capabilities

### 🦠 NexusAntivirus
- Runs at `BOOT_COMPLETED` with highest priority (999)
- Reads SentinelLab hardware scan result via system property
- SHA-256 file hashing against `sentinel_signatures.db`
- Shows status in status bar (shield icon)
- Settings panel: scan history, quarantine, DB update

### 🎬 Boot Animation (`bootanimation.zip`)
**Already generated — 159 real PNG frames, 3.2MB**
- `part0` (60 frames): KynetixOS logo fade-in
- `part1` (45 frames): SentinelLab scan sweep + "System Clean" ✓
- `part2` (30 frames): "Secured by Nexus" gold reveal
- `part3` (24 frames): Idle spinner loop

### 🏪 Aurora Store
- Pre-installed as privileged system app
- Replaces Google Play Store (GApps-free)
- Silent install/update permissions granted
- Anonymous mode enabled by default

### 🔧 NexusRecovery
- NexusUI-styled recovery (dark theme, rounded menus)
- Full menu: Install, Wipe, Backup, Mount, Advanced, SentinelLab, Reboot
- SentinelLab scan mode in recovery
- NANDroid backup/restore
- ADB sideload
- EDL mode access

---

## Build instructions

### Prerequisites
```bash
# Ubuntu 22.04 LTS
sudo apt update
sudo apt install -y \
    git curl repo python3 python3-pip \
    openjdk-17-jdk \
    build-essential gcc g++ \
    bc bison flex libssl-dev libelf-dev \
    libncurses-dev libz-dev libc6-dev-i386 \
    zip unzip rsync ccache ninja-build \
    libxml2-utils xsltproc

# Set up ccache (speeds up rebuilds massively)
export USE_CCACHE=1
export CCACHE_DIR=~/.ccache
ccache -M 100G
```

### Step 1 — Initialize AOSP + KynetixOS
```bash
mkdir -p ~/kynetixos && cd ~/kynetixos

# Init AOSP Android 15
repo init \
    -u https://android.googlesource.com/platform/manifest \
    -b android-15.0.0_r1 \
    --depth=1 \
    --partial-clone

# Add KynetixOS local manifest
mkdir -p .repo/local_manifests
cp /path/to/this/tree/build/target/kynetix_manifest.xml \
   .repo/local_manifests/

# Sync (takes 1-4 hours, ~300GB)
repo sync -j$(nproc) --force-sync --no-clone-bundle
```

### Step 2 — Copy KynetixOS tree
```bash
# Copy everything from this tree into the AOSP checkout
cp -r /path/to/KynetixOS/device/xiaomi/sapphire   device/xiaomi/
cp -r /path/to/KynetixOS/vendor/kynetix            vendor/
cp -r /path/to/KynetixOS/packages/NexusRecovery    packages/apps/
cp    /path/to/KynetixOS/kernel/configs/kynetix_defconfig \
      kernel/xiaomi/sapphire/arch/arm64/configs/
```

### Step 3 — Build
```bash
# Use the build script
chmod +x build/tools/build_kynetix.sh

# Full build (kernel + ROM + package)
./build/tools/build_kynetix.sh all

# Or manually:
source build/envsetup.sh
lunch kynetix_sapphire-user
m -j$(nproc) systemimage vendorimage bootimage NexusRecovery
```

### Step 4 — Flash
```bash
# Unlock bootloader first (Xiaomi Mi Unlock Tool)
# Boot into fastboot: Vol Down + Power

fastboot flash boot        out/target/product/sapphire/boot.img
fastboot flash vendor_boot out/target/product/sapphire/vendor_boot.img
fastboot flash system      out/target/product/sapphire/system.img
fastboot flash vendor      out/target/product/sapphire/vendor.img
fastboot flash product     out/target/product/sapphire/product.img
fastboot flash recovery    out/target/product/sapphire/recovery.img
fastboot -w  # wipe userdata
fastboot reboot
```

### Alternative — Flash via NexusRecovery
```bash
# Sideload flashable ZIP
adb sideload releases/KynetixOS_1.0.0_sapphire_YYYYMMDD.zip
```

---

## Boot sequence

```
Power on
  │
  ├─► Qualcomm XBL (primary bootloader)
  │     Secure boot fuse check
  │
  ├─► ABL / Android Bootloader
  │     AVB verification of boot.img
  │
  ├─► Kernel boot
  │     KynetixOS kernel (5.15.x-kynetix)
  │     dm-verity active on all partitions
  │
  ├─► init (early-init)
  │     SentinelLab Phase 1: Hardware scan
  │     TEE/QSEE handshake
  │
  ├─► init (init)
  │     SentinelLab Phase 2: Kernel scan
  │     dm-verity status check
  │
  ├─► Boot animation starts
  │     part0: KynetixOS logo
  │     part1: "NexusAntivirus — Scanning system..."
  │     part2: "Secured by Nexus ✓"
  │     part3: Idle spinner
  │
  ├─► SentinelLab Phase 3: System integrity
  │
  ├─► Zygote / Android framework
  │
  ├─► NexusAntivirus boot scan (BOOT_COMPLETED)
  │
  └─► NexusUI home screen
        Aurora Store ready
        SentinelLab realtime monitor active
```

---

## Properties reference

| Property | Value | Description |
|---|---|---|
| `ro.kynetix.version` | `1.0.0` | OS version |
| `ro.kynetix.codename` | `Sapphire` | Codename |
| `ro.nexusui.enabled` | `true` | NexusUI active |
| `ro.sentinellab.enabled` | `true` | SentinelLab active |
| `ro.sentinellab.hw_permission_level` | `3` | HW access level |
| `ro.nexusantivirus.boot_scan` | `true` | Boot scan |
| `ro.aurorastore.bundled` | `true` | Aurora Store |
| `persist.sys.kynetix.theme` | `dark` | Default theme |
| `persist.sys.kynetix.accent` | `0xFF2979FF` | Accent color |

---

*KynetixOS 1.0 — Built with ❤ on AOSP Android 15*  
*Secured by Nexus | NexusUI | SentinelLab*
