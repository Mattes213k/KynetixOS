# KynetixOS Developer Guide

## Architecture overview

```
┌─────────────────────────────────────────────────────────┐
│                    USER SPACE                           │
│  NexusLauncher  NexusSettings  NexusAntivirus  Aurora  │
│  ────────────────────────────────────────────────────── │
│                   NexusUI Layer                         │
│  SystemUI overlay  Framework overlay  Settings overlay  │
│  ────────────────────────────────────────────────────── │
│              Android Framework (AOSP Android 15)        │
├─────────────────────────────────────────────────────────┤
│                  SYSTEM SERVICES                        │
│  SentinelLabService  WindowManager  ActivityManager     │
│  ────────────────────────────────────────────────────── │
│                   SentinelLab Layer                     │
│  sentinellabd  sentinel_hw  sentinel_scan  sentinel_rt  │
├─────────────────────────────────────────────────────────┤
│                    KERNEL SPACE                         │
│  KynetixOS Kernel 5.15.x                               │
│  dm-verity | IMA | SELinux | WireGuard | BFQ           │
├─────────────────────────────────────────────────────────┤
│                   HARDWARE / TEE                        │
│  Qualcomm QSEE | QFPROM | Secure Boot | ARB fuses      │
│  SM7435 · AMOLED 120Hz · 108MP · NFC · Side FP        │
└─────────────────────────────────────────────────────────┘
```

---

## Boot sequence (detailed)

```
XBL (Primary Bootloader)
  └─► Checks secure boot fuse (QFPROM)
      Initializes DRAM, clocks, regulators

ABL (Android Bootloader)
  └─► Verifies boot.img via AVB 2.0
      Passes verified boot state to kernel cmdline
      (green=locked, yellow=custom key, orange=unlocked)

Kernel boot (kynetix-5.15.x)
  └─► Mounts initramfs
      Starts /init (first stage)
      dm-verity activated: system, vendor, product verified

init (first stage)
  └─► Mounts /metadata, /persist
      SentinelLab Phase 1: Hardware scan (sentinellab_hw)
        - Secure boot fuse check
        - QSEE/TEE handshake
        - Anti-rollback version check
        - Bootloader lock state

init (second stage)  
  └─► Mounts all dynamic partitions (super)
      SentinelLab Phase 2: Kernel scan (sentinellab_kernel)
        - dm-verity status on all partitions
        - IMA measurement log check
        - Kernel cmdline integrity

init.sapphire.rc
  └─► Hardware setup (fingerprint, display, NFC, USB)
      ZRAM setup (4GB)
      CPU governor: schedutil
      I/O scheduler: BFQ

Boot animation
  └─► part0: KynetixOS logo (1.0s)
      part1: NexusAntivirus scan sweep (0.75s) + "System Clean ✓"
      part2: "Secured by Nexus" reveal (0.5s)
      part3: Idle spinner (loops until framework ready)

SentinelLab Phase 3
  └─► System partition integrity (file hash verification)
      Sets ro.sentinellab.boot_clean=true if clean

Zygote → Android Framework
  └─► NexusUI applied via RRO overlays
      NexusSystemUI loads (status bar, QS, lockscreen)
      NexusLauncher starts as home activity

BOOT_COMPLETED
  └─► NexusAntivirus boot scan (highest priority receiver)
      SentinelLab realtime monitor starts (sentinellab_rt)
      Aurora Store initializes
      All apps ready
```

---

## Adding a new SentinelLab scan module

1. Create your scanner in `vendor/kynetix/security/sentinellab/lib/`:

```cpp
// my_scanner.cpp
#include "sentinel_hw.h"

namespace sentinellab {

HwScanResult checkMyThing() {
    HwScanResult r;
    r.component = "my_thing";
    // ... your scan logic ...
    r.ok = true;
    r.message = "My thing: OK";
    return r;
}

} // namespace sentinellab
```

2. Register in `sentinellabd.cpp` `sentinel_system_integrity()` or add a new mode.

3. Add SELinux permissions in `sepolicy/sentinellab.te` if your scanner
   needs access to new file types or devices.

4. Add a system property to report results:
   `android::base::SetProperty("sentinellab.mything_ok", "true");`

---

## NexusUI theming guide

All NexusUI values are controlled via system properties and RRO overlays.

### Add a new accent color

In `vendor/kynetix/overlay/framework/res/values/colors.xml`:
```xml
<color name="nexus_accent_new">#FF6D00</color>
```

In `packages/NexusSettings/src/NexusUIFragment.java`:
```java
// Add to ACCENT_NAMES / ACCENT_VALUES arrays
```

### Add a new font

1. Drop your `.ttf` files in `vendor/kynetix/prebuilt/fonts/`
2. Add to `vendor/kynetix/config/kynetix.mk` PRODUCT_COPY_FILES
3. Register in `vendor/kynetix/overlay/framework/res/font/` as font family XML
4. Add to the `nexusui_font` ListPreference in NexusUIFragment

### Add a new QS tile

In `packages/NexusSystemUI/src/NexusQuickSettings.java`:
```java
public static final String TILE_MYFEATURE = "myfeature";

// Add to DEFAULT_TILES array

// Add case in createTile():
case TILE_MYFEATURE:
    tile.setIcon(R.drawable.ic_qs_myfeature);
    tile.setLabel("My Feature");
    tile.setOnClickListener(v -> doMyThing());
    break;
```

---

## NexusRecovery: Adding a menu item

In `packages/NexusRecovery/nexus_recovery_ui.cpp`:

```cpp
// Add to GetMainMenuItems():
{"My Operation", "Description of what it does", ICON_CUSTOM},

// Handle in menu selection:
case 7: // index of your item
    runMyOperation();
    break;
```

---

## Property reference (full)

| Property | Default | Description |
|---|---|---|
| `ro.kynetix.version` | `1.0.0` | KynetixOS version |
| `ro.kynetix.codename` | `Sapphire` | Release codename |
| `ro.kynetix.build.type` | `OFFICIAL` | Build channel |
| `ro.kynetix.build.date` | `YYYYMMDD` | Build date |
| `ro.nexusui.version` | `1.0` | NexusUI version |
| `persist.sys.nexusui.theme` | `dark` | dark/light/auto |
| `persist.sys.nexusui.accent_color` | `0xFF2979FF` | ARGB accent |
| `persist.sys.nexusui.blur_enabled` | `true` | Blur effects |
| `persist.sys.nexusui.blur_radius` | `30` | Blur px radius |
| `persist.sys.nexusui.corner_radius` | `24` | dp corner radius |
| `persist.sys.nexusui.font` | `nexus_display` | Font family key |
| `persist.sys.nexusui.statusbar_clock` | `center` | left/center/right/hidden |
| `persist.sys.nexusui.aod_enabled` | `true` | Always-On Display |
| `persist.sys.nexusui.spring_animations` | `true` | Physics anims |
| `persist.sys.nexusui.network_speed` | `true` | Net speed in SB |
| `ro.sentinellab.version` | `1.0.0` | SentinelLab version |
| `ro.sentinellab.enabled` | `true` | SentinelLab on/off |
| `ro.sentinellab.hw_permission_level` | `3` | HW access level |
| `ro.sentinellab.hw_scan` | `true` | HW pre-scan |
| `ro.sentinellab.kernel_scan` | `true` | Kernel scan |
| `ro.sentinellab.dm_verity_enforce` | `true` | dm-verity strict |
| `ro.sentinellab.realtime_monitor` | `true` | RT monitoring |
| `ro.sentinellab.network_firewall` | `true` | Network firewall |
| `ro.sentinellab.boot_clean` | (set at boot) | Boot scan result |
| `sentinellab.threat_detected` | (set at boot) | Threat found flag |
| `sentinellab.hw_scan_complete` | (set at boot) | HW scan done |
| `sentinellab.kernel_scan_complete` | (set at boot) | Kernel scan done |
| `sentinellab.system_scan_complete` | (set at boot) | System scan done |
| `ro.nexusav.enabled` | `true` | NexusAntivirus on |
| `ro.nexusav.boot_scan` | `true` | Boot scan on |
| `ro.nexusav.db_version` | `2025.1` | Signature DB ver |
| `ro.aurorastore.bundled` | `true` | Aurora included |
| `ro.aurorastore.anonymous_mode` | `true` | No Google account |

---

## Signing release builds

```bash
# Generate release keys (do this ONCE, store securely offline)
mkdir ~/.kynetix-keys && cd ~/.kynetix-keys

# Platform key (signs system apps)
openssl genrsa -out platform.pem 4096
openssl req -new -x509 -key platform.pem -out platform.x509.pem \
    -days 10000 -subj "/CN=KynetixOS Platform/O=KynetixOS"

# OTA key (signs OTA packages)
openssl genrsa -out ota.pem 4096
openssl req -new -x509 -key ota.pem -out ota.x509.pem \
    -days 10000 -subj "/CN=KynetixOS OTA/O=KynetixOS"

# Build with your keys
export PRODUCT_DEFAULT_DEV_CERTIFICATE=~/.kynetix-keys/platform
./build/tools/build_kynetix.sh all

# Sign OTA package
sign_target_files_apks \
    -k ~/.kynetix-keys/ota \
    out/target/product/sapphire/target_files.zip \
    KynetixOS_signed_target.zip

ota_from_target_files \
    -k ~/.kynetix-keys/ota \
    KynetixOS_signed_target.zip \
    KynetixOS_1.0.0_sapphire_signed.zip
```

---

*KynetixOS 1.0 — Secured by Nexus*
