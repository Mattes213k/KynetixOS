#
# KynetixOS — device/xiaomi/sapphire/device.mk
# Target: Xiaomi Redmi Note 13 Pro (sapphire)
# Android 15 / KynetixOS 1.0
#

# Inherit AOSP device tree base
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/full_base_telephony.mk)

# Inherit KynetixOS vendor configuration
$(call inherit-product, vendor/kynetix/config/kynetix.mk)

# Inherit SentinelLab security framework
$(call inherit-product, vendor/kynetix/security/sentinellab/sentinellab.mk)

# Inherit NexusUI overlay
$(call inherit-product, vendor/kynetix/overlay/nexusui.mk)

# Device identifier
PRODUCT_NAME := kynetix_sapphire
PRODUCT_DEVICE := sapphire
PRODUCT_BRAND := Xiaomi
PRODUCT_MODEL := Redmi Note 13 Pro
PRODUCT_MANUFACTURER := Xiaomi
PRODUCT_RELEASE_NAME := KynetixOS

# KynetixOS versioning
KYNETIX_VERSION := 1.0.0
KYNETIX_BUILD_TYPE := OFFICIAL
KYNETIX_CODENAME := Sapphire

PRODUCT_BUILD_PROP_OVERRIDES += \
    TARGET_PRODUCT=kynetix_sapphire \
    PRODUCT_NAME=KynetixOS \
    BUILD_FINGERPRINT="Kynetix/KynetixOS/sapphire:15/AP3A.240905.015/$(shell date +%Y%m%d):user/release-keys"

# Shipping API level
PRODUCT_SHIPPING_API_LEVEL := 34

# Screen density
PRODUCT_AAPT_CONFIG := normal
PRODUCT_AAPT_PREF_CONFIG := xxhdpi

# Audio
$(call inherit-product, frameworks/av/services/audiopolicy/config/audio_policy_volumes.mk)

# Overlays — NexusUI
DEVICE_PACKAGE_OVERLAYS += \
    vendor/kynetix/overlay/framework \
    vendor/kynetix/overlay/SystemUI \
    vendor/kynetix/overlay/Settings \
    vendor/kynetix/overlay/Launcher

# Enforce RRO
PRODUCT_ENFORCE_RRO_TARGETS := *

# KynetixOS core packages
PRODUCT_PACKAGES += \
    NexusLauncher \
    NexusSystemUI \
    NexusSettings \
    NexusAntivirus \
    SentinelLabService \
    AuroraStore \
    NexusWallpapers \
    NexusFonts

# Recovery
PRODUCT_PACKAGES += \
    NexusRecovery

# Boot animation
PRODUCT_COPY_FILES += \
    vendor/kynetix/prebuilt/bootanimation/bootanimation.zip:$(TARGET_COPY_OUT_SYSTEM)/media/bootanimation.zip

# Sounds
PRODUCT_COPY_FILES += \
    vendor/kynetix/prebuilt/sounds/boot_complete.ogg:$(TARGET_COPY_OUT_PRODUCT)/media/audio/ui/boot_complete.ogg \
    vendor/kynetix/prebuilt/sounds/sentinel_scan.ogg:$(TARGET_COPY_OUT_PRODUCT)/media/audio/ui/sentinel_scan.ogg

# Fonts
PRODUCT_COPY_FILES += \
    vendor/kynetix/prebuilt/fonts/NexusDisplay-Regular.ttf:$(TARGET_COPY_OUT_PRODUCT)/fonts/NexusDisplay-Regular.ttf \
    vendor/kynetix/prebuilt/fonts/NexusDisplay-Bold.ttf:$(TARGET_COPY_OUT_PRODUCT)/fonts/NexusDisplay-Bold.ttf \
    vendor/kynetix/prebuilt/fonts/NexusMono-Regular.ttf:$(TARGET_COPY_OUT_PRODUCT)/fonts/NexusMono-Regular.ttf

# SentinelLab hardware-level security policy
PRODUCT_COPY_FILES += \
    vendor/kynetix/security/sentinellab/sepolicy/sentinel_hwscan.te:$(TARGET_COPY_OUT_VENDOR)/etc/selinux/vendor_file_contexts \
    vendor/kynetix/security/sentinellab/sentinel_config.xml:$(TARGET_COPY_OUT_VENDOR)/etc/sentinel_config.xml

# Kernel configs
TARGET_KERNEL_CONFIG := kynetix_defconfig
BOARD_KERNEL_CMDLINE += sentinellab.enabled=1 kynetix.secure=1

# Properties
PRODUCT_PROPERTY_OVERRIDES += \
    ro.kynetix.version=$(KYNETIX_VERSION) \
    ro.kynetix.build.type=$(KYNETIX_BUILD_TYPE) \
    ro.kynetix.codename=$(KYNETIX_CODENAME) \
    ro.nexusui.enabled=true \
    ro.sentinellab.enabled=true \
    ro.sentinellab.hw_access=true \
    ro.nexusantivirus.boot_scan=true \
    persist.sys.kynetix.theme=dark \
    persist.sys.kynetix.accent=0xFF2979FF
