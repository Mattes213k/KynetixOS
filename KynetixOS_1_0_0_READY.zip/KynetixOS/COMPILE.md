# KynetixOS — Compilation Guide

Complete guide to building KynetixOS from source on Ubuntu 22.04 LTS.
Two targets are available: **GSI** (all Treble Android devices) and
**sapphire** (Xiaomi Redmi Note 13 Pro).

---

## Quick Start

```bash
# 1. Run the setup script ONCE on a fresh Ubuntu 22.04 machine:
chmod +x build/tools/setup_ubuntu.sh
./build/tools/setup_ubuntu.sh

# 2. Reload shell
source ~/.bashrc

# 3. Build GSI (recommended — works on all Treble devices)
./build/tools/build_kynetix_gsi.sh arm64

# 4. Build device-specific (Xiaomi Redmi Note 13 Pro only)
./build/tools/build_kynetix.sh
```

---

## System Requirements

| Component | Minimum | Recommended |
|---|---|---|
| OS | Ubuntu 22.04 LTS | Ubuntu 22.04 LTS |
| RAM | 32 GB | 64 GB+ |
| Storage | 300 GB free | 500 GB+ SSD |
| CPU cores | 8 | 16–32 |
| Internet | Required for sync | Stable broadband |
| Java | OpenJDK 17 | OpenJDK 17 |

---

## What `setup_ubuntu.sh` Does

1. **System check** — verifies Ubuntu version, RAM, and disk space
2. **Swap** — creates a 32 GB swap file if you have less than 64 GB RAM
3. **APT packages** — installs all required build dependencies (gcc, flex, bison, python3, ninja, etc.)
4. **Java 17** — installs OpenJDK 17 and sets it as default
5. **repo tool** — downloads Google's `repo` to `~/bin/repo`
6. **ccache** — configures a 50 GB ccache (cuts rebuild time from hours to ~20 min)
7. **Git** — sets git identity if not already configured
8. **Boot animation check** — verifies `vendor/kynetix/prebuilt/bootanimation/bootanimation.zip`
   is valid and PNGs are stored (not deflated)

---

## Boot Animation

KynetixOS ships a custom boot animation at:
```
vendor/kynetix/prebuilt/bootanimation/bootanimation.zip
```

**Specification:**
- Resolution: 1080×2400 (FHD+)
- Frame rate: 60 fps
- 160 frames across 4 parts
- part0–2 play once (intro/animation), part3 loops until boot completes

**How it gets installed:**
`nexusui.mk` → `PRODUCT_COPY_FILES` → `/system/media/bootanimation.zip`

Both the GSI and sapphire builds use the same animation file.

---

## Build Targets

### GSI (`kynetix_gsi`) — All Treble Devices

```bash
./build/tools/build_kynetix_gsi.sh arm64
# Output: releases/KynetixOS_1.0.0_GSI_arm64_YYYYMMDD.zip
#   ├── system.img        flash this
#   ├── product.img       flash this (if device has product partition)
#   └── system_ext.img    flash this (if device has system_ext partition)
```

Flashing:
```bash
adb reboot bootloader
fastboot reboot fastboot
fastboot flash system system.img
fastboot flash product product.img
fastboot flash system_ext system_ext.img
fastboot -w
fastboot reboot
```

### Sapphire (`kynetix_sapphire`) — Xiaomi Redmi Note 13 Pro

```bash
./build/tools/build_kynetix.sh
# Output: releases/KynetixOS_1.0.0_sapphire_YYYYMMDD.zip
#   ├── system.img, vendor.img, product.img, system_ext.img
#   ├── boot.img, vendor_boot.img, recovery.img
#   └── (full flashable ZIP for NexusRecovery / TWRP sideload)
```

---

## Build Variants

| Variant | Command suffix | Description |
|---|---|---|
| user | `-user` | Production build, no ADB root |
| userdebug | `-userdebug` | Production + ADB root |
| eng | `-eng` | Full debug, all tools |

Change variant in `lunch` call inside the build scripts.

---

## ccache

ccache stores compiled object files. After the first build:
- Full rebuild: 20–45 minutes (vs 2–6 hours cold)
- Check stats: `ccache -s`
- Clear cache: `ccache -C`
- Default size: 50 GB (`~/.ccache`)

---

## Directory Structure (relevant to compilation)

```
KynetixOS/
├── build/
│   ├── target/kynetix_manifest.xml    ← place in .repo/local_manifests/
│   └── tools/
│       ├── setup_ubuntu.sh            ← RUN THIS FIRST
│       ├── build_kynetix.sh           ← sapphire build
│       └── build_kynetix_gsi.sh       ← GSI build
├── device/
│   ├── xiaomi/sapphire/               ← Xiaomi-specific device tree
│   └── gsi/kynetix/                   ← GSI device tree (all Treble)
├── vendor/kynetix/
│   ├── config/kynetix.mk              ← core OS properties & packages
│   ├── overlay/nexusui.mk             ← NexusUI + boot animation wiring
│   ├── prebuilt/bootanimation/
│   │   ├── bootanimation.zip          ← the actual animation (1080×2400 60fps)
│   │   ├── Android.mk                 ← build system module definition
│   │   └── BOOTANIM_SPEC.txt          ← animation spec / documentation
│   └── security/sentinellab/
│       └── sentinellab.mk             ← GSI-aware (hw_scan conditional)
└── kernel/
    └── configs/kynetix_defconfig      ← used by sapphire build only
```

---

## Common Issues

**`FAILED: out/...` during system image build**
- Usually a RAM issue. Check swap is enabled: `free -h`
- Reduce parallel jobs: edit `JOBS=$(nproc --all)` → `JOBS=8` in build script

**`repo sync` fails / partial clone errors**
- Run `repo sync --force-sync -j4` with fewer parallel jobs

**Boot animation not showing**
- Verify PNGs are stored: `unzip -l bootanimation.zip | grep -v stored | grep png`
- If deflated, repack: `cd extracted_dir && zip -r0 ../bootanimation.zip .`
- Check `/system/media/bootanimation.zip` exists on device: `adb shell ls /system/media/`

**SentinelLab crashes on non-Qualcomm device (GSI)**
- Expected on first GSI boot if TEE HAL mismatch. SentinelLab auto-falls back to software mode.
- Check: `adb shell getprop ro.sentinellab.tee_flavor` → should show `software` or detected flavor

**`lunch kynetix_gsi-user` not found**
- Make sure `device/gsi/kynetix/AndroidProducts.mk` is present
- Run `source build/envsetup.sh` again before `lunch`
