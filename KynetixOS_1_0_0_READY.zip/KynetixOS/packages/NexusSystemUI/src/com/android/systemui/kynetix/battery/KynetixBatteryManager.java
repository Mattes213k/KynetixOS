package com.android.systemui.kynetix.battery;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.android.systemui.kynetix.errors.NexusErrorDialog;

/**
 * KynetixOS Battery Manager
 * ──────────────────────────
 * Sleduje stav baterie a reaguje na nízkou / kritickou úroveň:
 *
 *  > 20%   → normální
 *  15–20%  → varování (notifikace)
 *  5–15%   → nízká baterie (dialog + nabídka úsporného režimu)
 *  < 5%    → kritická (dialog + automatický úsporný režim)
 *  Přehřátá baterie → varování
 *  Poškozená baterie → varování
 */
public class KynetixBatteryManager {

    private static final String TAG = "KynetixBattery";

    // Prahy baterie (%)
    private static final int BATTERY_LOW      = 20;
    private static final int BATTERY_CRITICAL = 5;

    // Teplotní prahy baterie (°C × 10 — Android vrací v desetinách stupně)
    private static final int BATTERY_TEMP_WARN = 450; // 45°C

    private final Context mContext;
    private final Handler mHandler;

    private int  mLastLevel  = -1;
    private boolean mCharging = false;
    private boolean mLowShown = false;
    private boolean mCritShown = false;

    public KynetixBatteryManager(Context context) {
        mContext = context;
        mHandler = new Handler(Looper.getMainLooper());
    }

    public void start() {
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(Intent.ACTION_BATTERY_LOW);
        f.addAction(Intent.ACTION_BATTERY_OKAY);
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        mContext.registerReceiver(mBatteryReceiver, f);
        Log.i(TAG, "Battery monitoring started.");
    }

    public void stop() {
        try { mContext.unregisterReceiver(mBatteryReceiver); }
        catch (Exception ignored) {}
    }

    private final BroadcastReceiver mBatteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            String action = intent.getAction();
            if (action == null) return;

            switch (action) {
                case Intent.ACTION_BATTERY_CHANGED:
                    handleBatteryChanged(intent);
                    break;
                case Intent.ACTION_BATTERY_OKAY:
                    // Baterie se nabila nad prahovou hodnotu
                    mLowShown  = false;
                    mCritShown = false;
                    break;
                case Intent.ACTION_POWER_CONNECTED:
                    mCharging = true;
                    mLowShown = false;
                    mCritShown = false;
                    break;
                case Intent.ACTION_POWER_DISCONNECTED:
                    mCharging = false;
                    break;
            }
        }
    };

    private void handleBatteryChanged(Intent intent) {
        int level  = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale  = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int temp   = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);

        int pct = (scale > 0) ? (level * 100 / scale) : level;
        mCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING
                  || status == BatteryManager.BATTERY_STATUS_FULL);

        if (pct == mLastLevel) return;
        mLastLevel = pct;

        Log.d(TAG, String.format("Battery: %d%% | charging: %b | temp: %.1f°C",
            pct, mCharging, temp / 10.0f));

        // Přeskočit dialogy pokud se nabíjí
        if (mCharging) return;

        // Zdraví baterie
        if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
            showBatteryOverheat(temp / 10.0f);
        } else if (health == BatteryManager.BATTERY_HEALTH_DEAD
                || health == BatteryManager.BATTERY_HEALTH_FAILURE) {
            showBatteryDead();
        }

        // Teplota baterie
        if (temp > BATTERY_TEMP_WARN) {
            Log.w(TAG, "Battery temperature high: " + (temp / 10.0f) + "°C");
        }

        // Úroveň nabití
        if (pct <= BATTERY_CRITICAL && !mCritShown) {
            mCritShown = true;
            mLowShown  = true;
            showCriticalBattery(pct);
        } else if (pct <= BATTERY_LOW && !mLowShown) {
            mLowShown = true;
            showLowBattery(pct);
        }
    }

    private void showLowBattery(int pct) {
        NexusErrorDialog.show(mContext,
            NexusErrorDialog.ErrorType.LOW_BATTERY,
            pct + "%",
            "Baterie je nízká. Připoj nabíječku nebo zapni úsporný režim.",
            true);
    }

    private void showCriticalBattery(int pct) {
        NexusErrorDialog.show(mContext,
            NexusErrorDialog.ErrorType.CRITICAL_BATTERY,
            pct + "%",
            "Baterie je kriticky nízká!\nTelefon se brzy vypne.",
            true);
    }

    private void showBatteryOverheat(float tempC) {
        NexusErrorDialog.show(mContext,
            NexusErrorDialog.ErrorType.THERMAL_CRITICAL,
            String.format("Baterie: %.0f°C", tempC),
            "Baterie se přehřívá. Přestaň nabíjet a nech telefon vychladnout.",
            true);
    }

    private void showBatteryDead() {
        NexusErrorDialog.show(mContext,
            NexusErrorDialog.ErrorType.SYSTEM_ERROR,
            "Baterie poškozena",
            "Baterie je poškozena nebo opotřebována. Doporučujeme výměnu.",
            true);
    }

    public int getLevel()   { return mLastLevel; }
    public boolean isCharging() { return mCharging; }
}
