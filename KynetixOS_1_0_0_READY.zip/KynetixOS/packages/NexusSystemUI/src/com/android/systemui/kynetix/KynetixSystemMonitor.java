package com.android.systemui.kynetix;

import android.content.Context;
import android.util.Log;

import com.android.systemui.kynetix.battery.KynetixBatteryManager;
import com.android.systemui.kynetix.crash.KynetixCrashHandler;
import com.android.systemui.kynetix.errors.NexusErrorDialog;
import com.android.systemui.kynetix.thermal.KynetixThermalManager;

/**
 * KynetixSystemMonitor
 * ─────────────────────
 * Centrální orchestrátor všech KynetixOS systémových monitorů.
 * Spouští se při startu NexusSystemUI.
 *
 * Koordinuje:
 *   • KynetixThermalManager  — přehřátí CPU
 *   • KynetixBatteryManager  — baterie
 *   • KynetixCrashHandler    — páda aplikací
 *   • NexusErrorDialog        — centrální chybové dialogy
 */
public class KynetixSystemMonitor {

    private static final String TAG = "KynetixMonitor";

    private static KynetixSystemMonitor sInstance;

    private final Context               mContext;
    private final KynetixThermalManager mThermal;
    private final KynetixBatteryManager mBattery;

    private boolean mStarted = false;

    private KynetixSystemMonitor(Context context) {
        mContext = context.getApplicationContext();
        mThermal = new KynetixThermalManager(mContext);
        mBattery = new KynetixBatteryManager(mContext);
    }

    public static synchronized KynetixSystemMonitor getInstance(Context ctx) {
        if (sInstance == null) {
            sInstance = new KynetixSystemMonitor(ctx);
        }
        return sInstance;
    }

    /**
     * Spustí všechny monitory.
     * Volej z NexusSystemUI při startu.
     */
    public void start() {
        if (mStarted) return;
        mStarted = true;

        Log.i(TAG, "═══ KynetixOS System Monitor starting ═══");

        // 1. Crash handler (první — zachytí pády ostatních)
        KynetixCrashHandler.install(mContext);
        Log.i(TAG, "✓ Crash handler installed");

        // 2. Thermal monitor
        mThermal.start();
        Log.i(TAG, "✓ Thermal monitor started");

        // 3. Battery monitor
        mBattery.start();
        Log.i(TAG, "✓ Battery monitor started");

        Log.i(TAG, "═══ All monitors running ═══");
    }

    /**
     * Zastaví všechny monitory.
     */
    public void stop() {
        mThermal.stop();
        mBattery.stop();
        mStarted = false;
        Log.i(TAG, "KynetixOS System Monitor stopped.");
    }

    // ── Přístup ke stavům ─────────────────────────────────────────────────────

    public float getCurrentTemperature() {
        return mThermal.getCurrentTemperature();
    }

    public KynetixThermalManager.ThermalState getThermalState() {
        return mThermal.getCurrentState();
    }

    public int getBatteryLevel() {
        return mBattery.getLevel();
    }

    public boolean isCharging() {
        return mBattery.isCharging();
    }

    /**
     * Zobraz systémový error dialog ručně (pro použití z jiných komponent).
     */
    public void showError(NexusErrorDialog.ErrorType type,
                          String subtitle, String detail, boolean dismissible) {
        NexusErrorDialog.show(mContext, type, subtitle, detail, dismissible);
    }
}
