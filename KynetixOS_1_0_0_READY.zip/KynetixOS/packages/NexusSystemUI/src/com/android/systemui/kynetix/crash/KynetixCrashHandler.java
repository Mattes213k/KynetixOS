package com.android.systemui.kynetix.crash;

import android.content.Context;
import android.util.Log;

import com.android.systemui.kynetix.errors.NexusErrorDialog;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * KynetixOS Crash Handler
 * ────────────────────────
 * Zachytí pády aplikací, zobrazí NexusUI dialog
 * a uloží crash log do /data/kynetix/crashes/
 *
 * Instalace: zavolej KynetixCrashHandler.install(context) v Application.onCreate()
 */
public class KynetixCrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG      = "KynetixCrash";
    private static final String CRASH_DIR = "/data/kynetix/crashes";

    private final Context                       mContext;
    private final Thread.UncaughtExceptionHandler mDefaultHandler;

    private KynetixCrashHandler(Context ctx) {
        mContext        = ctx.getApplicationContext();
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
    }

    /**
     * Nainstaluje KynetixCrashHandler jako globální handler.
     * Volej v Application.onCreate().
     */
    public static void install(Context context) {
        Thread.setDefaultUncaughtExceptionHandler(new KynetixCrashHandler(context));
        Log.i(TAG, "KynetixCrashHandler installed.");
    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        try {
            String appName  = getAppName();
            String crashLog = buildCrashLog(thread, ex, appName);

            // 1. Ulož log
            saveCrashLog(appName, crashLog);

            // 2. Zobraz NexusUI dialog
            NexusErrorDialog.show(
                mContext,
                NexusErrorDialog.ErrorType.APP_CRASH,
                appName,
                "Aplikace neočekávaně skončila.\n\n" +
                "Chyba: " + ex.getClass().getSimpleName() +
                (ex.getMessage() != null ? "\n" + ex.getMessage() : ""),
                true
            );

            Log.e(TAG, "App crash captured: " + appName, ex);

        } catch (Exception e) {
            Log.e(TAG, "Error in crash handler itself", e);
        }

        // Předej výchozímu handleru (Android ukončí proces)
        if (mDefaultHandler != null) {
            mDefaultHandler.uncaughtException(thread, ex);
        }
    }

    // ── Crash log ─────────────────────────────────────────────────────────────

    private String buildCrashLog(Thread thread, Throwable ex, String appName) {
        StringBuilder sb = new StringBuilder();
        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            .format(new Date());

        sb.append("═══════════════════════════════════════\n");
        sb.append("KynetixOS Crash Report\n");
        sb.append("═══════════════════════════════════════\n");
        sb.append("Datum:     ").append(date).append("\n");
        sb.append("Aplikace:  ").append(appName).append("\n");
        sb.append("Vlákno:    ").append(thread.getName()).append("\n");
        sb.append("Android:   ").append(android.os.Build.VERSION.RELEASE).append("\n");
        sb.append("KynetixOS: ").append(getKynetixVersion()).append("\n");
        sb.append("Zařízení:  ").append(android.os.Build.MODEL).append("\n");
        sb.append("═══════════════════════════════════════\n\n");

        sb.append("VÝJIMKA:\n");
        sb.append(ex.getClass().getName()).append(": ").append(ex.getMessage()).append("\n\n");

        sb.append("STACK TRACE:\n");
        for (StackTraceElement el : ex.getStackTrace()) {
            sb.append("  at ").append(el.toString()).append("\n");
        }

        // Příčina (cause)
        Throwable cause = ex.getCause();
        if (cause != null) {
            sb.append("\nZPŮSOBENO:\n");
            sb.append(cause.getClass().getName()).append(": ")
              .append(cause.getMessage()).append("\n");
            for (StackTraceElement el : cause.getStackTrace()) {
                sb.append("  at ").append(el.toString()).append("\n");
            }
        }

        return sb.toString();
    }

    private void saveCrashLog(String appName, String log) {
        try {
            File dir = new File(CRASH_DIR);
            dir.mkdirs();

            String fname = "crash_" + appName.replaceAll("[^a-zA-Z0-9]", "_")
                + "_" + System.currentTimeMillis() + ".txt";
            File f = new File(dir, fname);

            try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
                pw.print(log);
            }
            Log.i(TAG, "Crash log saved: " + f.getAbsolutePath());
        } catch (Exception e) {
            Log.w(TAG, "Could not save crash log: " + e.getMessage());
        }
    }

    private String getAppName() {
        try {
            android.content.pm.ApplicationInfo ai =
                mContext.getApplicationInfo();
            return mContext.getPackageManager()
                .getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return mContext.getPackageName();
        }
    }

    private String getKynetixVersion() {
        return android.os.SystemProperties.get(
            "ro.kynetix.version", "unknown");
    }
}
