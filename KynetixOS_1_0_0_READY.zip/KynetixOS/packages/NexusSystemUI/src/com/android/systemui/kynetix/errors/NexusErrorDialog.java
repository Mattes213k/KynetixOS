package com.android.systemui.kynetix.errors;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * NexusErrorDialog
 * ─────────────────
 * Centrální systém chybových dialogů pro KynetixOS.
 *
 * Podporované typy chyb:
 *   THERMAL_WARNING    — telefon se zahřívá
 *   THERMAL_CRITICAL   — přehřátí, výkon snížen
 *   THERMAL_EMERGENCY  — kritické přehřátí, vypnutí
 *   APP_CRASH          — pád aplikace
 *   LOW_BATTERY        — nízká baterie
 *   CRITICAL_BATTERY   — kritická baterie
 *   STORAGE_FULL       — plné úložiště
 *   NO_NETWORK         — bez připojení
 *   SENTINEL_THREAT    — SentinelLab detekoval hrozbu
 *   SYSTEM_ERROR       — obecná systémová chyba
 *   KERNEL_PANIC       — kernel panic (recovery dialog)
 */
public class NexusErrorDialog {

    public enum ErrorType {
        THERMAL_WARNING,
        THERMAL_CRITICAL,
        THERMAL_EMERGENCY,
        APP_CRASH,
        LOW_BATTERY,
        CRITICAL_BATTERY,
        STORAGE_FULL,
        NO_NETWORK,
        SENTINEL_THREAT,
        SYSTEM_ERROR,
        KERNEL_PANIC
    }

    /**
     * Zobrazí chybový dialog.
     *
     * @param context     context (SystemUI nebo app)
     * @param type        typ chyby
     * @param subtitle    krátký doplňující text (např. "52°C" nebo název apky)
     * @param detail      detailní popis nebo null
     * @param dismissible může uživatel dialog zavřít?
     */
    public static void show(Context context, ErrorType type,
                            String subtitle, String detail,
                            boolean dismissible) {
        new Handler(Looper.getMainLooper()).post(() ->
            buildAndShow(context, type, subtitle, detail, dismissible));
    }

    private static void buildAndShow(Context context, ErrorType type,
                                     String subtitle, String detail,
                                     boolean dismissible) {
        ErrorConfig cfg = configFor(type);

        Dialog dialog = new Dialog(context,
            android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_nexus_error);
        dialog.setCancelable(dismissible);
        dialog.setCanceledOnTouchOutside(false);

        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.CENTER);
            // Zobrazit nad lock screenen pro kritické chyby
            if (!dismissible) {
                w.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
            }
        }

        // ── Naplň UI ───────────────────────────────────────────────────────
        ImageView  ivIcon    = dialog.findViewById(R.id.error_icon);
        TextView   tvTitle   = dialog.findViewById(R.id.error_title);
        TextView   tvSub     = dialog.findViewById(R.id.error_subtitle);
        TextView   tvDetail  = dialog.findViewById(R.id.error_detail);
        Button     btnDismiss= dialog.findViewById(R.id.btn_dismiss);
        Button     btnAction = dialog.findViewById(R.id.btn_action);
        View       accentBar = dialog.findViewById(R.id.accent_bar);

        ivIcon.setImageResource(cfg.iconRes);
        tvTitle.setText(cfg.title);
        tvTitle.setTextColor(cfg.accentColor);
        accentBar.setBackgroundColor(cfg.accentColor);

        if (subtitle != null && !subtitle.isEmpty()) {
            tvSub.setText(subtitle);
            tvSub.setVisibility(View.VISIBLE);
        } else {
            tvSub.setVisibility(View.GONE);
        }

        if (detail != null && !detail.isEmpty()) {
            tvDetail.setText(detail);
            tvDetail.setVisibility(View.VISIBLE);
        } else {
            tvDetail.setVisibility(View.GONE);
        }

        // Zavřít tlačítko
        if (dismissible) {
            btnDismiss.setVisibility(View.VISIBLE);
            btnDismiss.setText(cfg.dismissText);
            btnDismiss.setOnClickListener(v -> dialog.dismiss());
        } else {
            btnDismiss.setVisibility(View.GONE);
        }

        // Akční tlačítko (volitelné)
        if (cfg.actionText != null) {
            btnAction.setVisibility(View.VISIBLE);
            btnAction.setText(cfg.actionText);
            btnAction.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(cfg.accentColor));
            btnAction.setOnClickListener(v -> {
                cfg.onAction.run();
                dialog.dismiss();
            });
        } else {
            btnAction.setVisibility(View.GONE);
        }

        dialog.show();
    }

    // ── Konfigurace pro každý typ chyby ──────────────────────────────────────

    private static ErrorConfig configFor(ErrorType type) {
        switch (type) {

            case THERMAL_WARNING:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "Telefon se zahřívá",
                    0xFFFF6F00,
                    "Rozumím",
                    null, null
                );

            case THERMAL_CRITICAL:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "Přehřátí — výkon snížen",
                    0xFFD32F2F,
                    "OK",
                    "Restartovat", () -> android.os.Process.killProcess(android.os.Process.myPid())
                );

            case THERMAL_EMERGENCY:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "KRITICKÉ PŘEHŘÁTÍ",
                    0xFFB71C1C,
                    null,          // nedismissible
                    null, null
                );

            case APP_CRASH:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "Aplikace spadla",
                    0xFF2979FF,
                    "Zavřít",
                    "Nahlásit chybu", () -> { /* odešli crash report */ }
                );

            case LOW_BATTERY:
                return new ErrorConfig(
                    android.R.drawable.ic_lock_silent_mode_off,
                    "Nízká baterie",
                    0xFFFF6F00,
                    "OK",
                    "Úsporný režim", () -> { /* zapni battery saver */ }
                );

            case CRITICAL_BATTERY:
                return new ErrorConfig(
                    android.R.drawable.ic_lock_silent_mode_off,
                    "Kritická baterie — připoj nabíječku",
                    0xFFD32F2F,
                    "OK",
                    null, null
                );

            case STORAGE_FULL:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "Úložiště je plné",
                    0xFFFF6F00,
                    "Zavřít",
                    "Spravovat úložiště", () -> { /* otevři správce souborů */ }
                );

            case NO_NETWORK:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "Bez připojení k internetu",
                    0xFF607D8B,
                    "OK",
                    "Nastavení sítě", () -> { /* otevři Wi-Fi nastavení */ }
                );

            case SENTINEL_THREAT:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "SentinelLab: Hrozba detekována!",
                    0xFFD32F2F,
                    "Ignorovat",
                    "Odstranit hrozbu", () -> { /* spusť SentinelLab scan */ }
                );

            case KERNEL_PANIC:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "Systémová chyba — restartování",
                    0xFF880E4F,
                    null,
                    null, null
                );

            case SYSTEM_ERROR:
            default:
                return new ErrorConfig(
                    android.R.drawable.ic_dialog_alert,
                    "Systémová chyba",
                    0xFF2979FF,
                    "Zavřít",
                    "Restart", () -> android.os.Process.killProcess(android.os.Process.myPid())
                );
        }
    }

    // ── Data class pro konfiguraci ────────────────────────────────────────────

    private static class ErrorConfig {
        final int    iconRes;
        final String title;
        final int    accentColor;
        final String dismissText;
        final String actionText;
        final Runnable onAction;

        ErrorConfig(int iconRes, String title, int accentColor,
                    String dismissText, String actionText, Runnable onAction) {
            this.iconRes     = iconRes;
            this.title       = title;
            this.accentColor = accentColor;
            this.dismissText = dismissText;
            this.actionText  = actionText;
            this.onAction    = onAction;
        }
    }
}
