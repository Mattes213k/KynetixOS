package com.android.systemui.kynetix.thermal;

import android.util.Log;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * ThermalReader
 * Čte teplotu CPU z různých sysfs cest.
 * Funguje na Qualcomm, MediaTek, Exynos i generických zařízeních (GSI).
 */
public class ThermalReader {

    private static final String TAG = "KynetixThermalReader";

    // Sysfs cesty pro různé SoC (zkouší postupně)
    private static final String[] THERMAL_PATHS = {
        // Qualcomm (Snapdragon)
        "/sys/class/thermal/thermal_zone0/temp",
        "/sys/class/thermal/thermal_zone1/temp",
        "/sys/devices/virtual/thermal/thermal_zone0/temp",
        // MediaTek
        "/sys/class/thermal/thermal_zone4/temp",
        "/sys/devices/virtual/thermal/thermal_zone4/temp",
        // Samsung Exynos
        "/sys/class/thermal/thermal_zone7/temp",
        // Generická cesta (GSI fallback)
        "/sys/class/hwmon/hwmon0/temp1_input",
        "/sys/class/hwmon/hwmon1/temp1_input",
    };

    // Úspěšná cesta — cachujeme pro efektivitu
    private String mActivePath = null;

    /**
     * Vrátí teplotu CPU ve stupních Celsius.
     * Vrátí 0.0 pokud nelze přečíst.
     */
    public float readCpuTemperature() {
        if (mActivePath != null) {
            float t = readFromPath(mActivePath);
            if (t > 0) return t;
            mActivePath = null; // reset pokud cesta přestala fungovat
        }

        // Projdi všechny cesty
        for (String path : THERMAL_PATHS) {
            float t = readFromPath(path);
            if (t > 0) {
                mActivePath = path;
                Log.d(TAG, "Using thermal path: " + path + " → " + t + "°C");
                return t;
            }
        }

        Log.w(TAG, "No thermal sensor found — returning 0°C");
        return 0.0f;
    }

    private float readFromPath(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line = br.readLine();
            if (line == null) return 0;
            long raw = Long.parseLong(line.trim());
            // Většina sysfs vrací m°C (milistupně), dělíme 1000
            // Pokud je hodnota malá (<200), je to již °C
            return raw > 200 ? raw / 1000.0f : (float) raw;
        } catch (IOException | NumberFormatException e) {
            return 0;
        }
    }
}
