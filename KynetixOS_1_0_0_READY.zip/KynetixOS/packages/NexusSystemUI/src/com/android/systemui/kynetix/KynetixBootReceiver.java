package com.android.systemui.kynetix;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * KynetixBootReceiver
 * ────────────────────
 * Spustí KynetixSystemMonitor ihned po startu zařízení.
 * Registrován na BOOT_COMPLETED a LOCKED_BOOT_COMPLETED.
 */
public class KynetixBootReceiver extends BroadcastReceiver {

    private static final String TAG = "KynetixBoot";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.i(TAG, "Boot received: " + action);

        // Spusť všechny monitory
        KynetixSystemMonitor monitor =
            KynetixSystemMonitor.getInstance(context);
        monitor.start();

        Log.i(TAG, "KynetixOS monitors started after boot.");
    }
}
