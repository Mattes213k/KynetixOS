package com.android.systemui.kynetix.thermal;

import android.util.Log;
import java.io.FileWriter;
import java.io.IOException;

/**
 * ThermalWriter
 * Nastavuje CPU governor / throttling profil přes sysfs.
 * Vyžaduje systémová oprávnění (spouští se jako SystemUI).
 */
public class ThermalWriter {

    private static final String TAG = "KynetixThermalWriter";

    // CPU governor cesta
    private static final String GOVERNOR_PATH =
        "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor";

    // Qualcomm thermal engine config
    private static final String QCOM_THERMAL_PATH =
        "/sys/class/thermal/thermal_message/sconfig";

    /**
     * Nastaví throttling profil.
     *
     * @param profile "performance" | "balanced" | "conservative" | "powersave"
     */
    public static void setThrottleProfile(String profile) {
        // CPU governor
        writeToPath(GOVERNOR_PATH, profile);

        // Qualcomm specifické (ignoruje se na jiných SoC)
        switch (profile) {
            case "conservative":
            case "powersave":
                writeToPath(QCOM_THERMAL_PATH, "10"); // thermal throttle level
                break;
            case "balanced":
                writeToPath(QCOM_THERMAL_PATH, "5");
                break;
            case "performance":
                writeToPath(QCOM_THERMAL_PATH, "0");
                break;
        }

        Log.i(TAG, "Throttle profile set: " + profile);
    }

    private static void writeToPath(String path, String value) {
        try (FileWriter fw = new FileWriter(path)) {
            fw.write(value);
        } catch (IOException e) {
            // Tiché selhání — ne všechna zařízení mají všechny cesty
            Log.d(TAG, "Cannot write to " + path + ": " + e.getMessage());
        }
    }
}
