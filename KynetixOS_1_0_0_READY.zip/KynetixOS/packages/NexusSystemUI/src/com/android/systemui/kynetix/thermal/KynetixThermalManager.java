package com.android.systemui.kynetix.thermal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;

import com.android.systemui.kynetix.errors.NexusErrorDialog;

/**
 * KynetixOS Thermal Manager
 * ─────────────────────────
 * Sleduje teplotu telefonu a reaguje na přehřátí:
 *
 *  < 40°C  → normální provoz
 *  40–50°C → varování (notifikace)
 *  50–60°C → kritické (dialog + snížení výkonu)
 *  > 60°C  → nouzové vypnutí
 *
 * Integruje se s SentinelLab pro logování tepelných událostí.
 */
public class KynetixThermalManager {

    private static final String TAG = "KynetixThermal";

    // Teplotní prahy (°C)
    public static final float TEMP_WARN     = 40.0f;
    public static final float TEMP_CRITICAL = 50.0f;
    public static final float TEMP_SHUTDOWN  = 60.0f;

    // Notifikační kanál
    private static final String CHANNEL_ID   = "kynetix_thermal";
    private static final int    NOTIF_WARN   = 2001;
    private static final int    NOTIF_CRIT   = 2002;

    // Interval kontroly teploty (ms)
    private static final long CHECK_INTERVAL_NORMAL   = 10_000; // 10s
    private static final long CHECK_INTERVAL_ELEVATED = 3_000;  // 3s při zvýšené teplotě

    private final Context             mContext;
    private final Handler             mHandler;
    private final NotificationManager mNm;
    private final PowerManager        mPm;
    private final ThermalReader       mReader;

    private ThermalState mCurrentState = ThermalState.NORMAL;
    private float        mLastTemp     = 0f;
    private boolean      mRunning      = false;

    public enum ThermalState {
        NORMAL,    // < 40°C
        WARNING,   // 40–50°C
        CRITICAL,  // 50–60°C
        EMERGENCY  // > 60°C
    }

    public KynetixThermalManager(Context context) {
        mContext = context;
        mHandler = new Handler(Looper.getMainLooper());
        mNm      = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        mPm      = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        mReader  = new ThermalReader();

        createNotificationChannels();
    }

    // ── Start / Stop ──────────────────────────────────────────────────────────

    public void start() {
        if (mRunning) return;
        mRunning = true;
        Log.i(TAG, "Thermal monitoring started.");
        scheduleCheck(CHECK_INTERVAL_NORMAL);
    }

    public void stop() {
        mRunning = false;
        mHandler.removeCallbacksAndMessages(null);
        Log.i(TAG, "Thermal monitoring stopped.");
    }

    // ── Kontrolní smyčka ──────────────────────────────────────────────────────

    private final Runnable mCheckRunnable = () -> {
        if (!mRunning) return;

        float temp = mReader.readCpuTemperature();
        mLastTemp = temp;

        ThermalState newState = stateForTemp(temp);
        if (newState != mCurrentState) {
            onStateChanged(mCurrentState, newState, temp);
            mCurrentState = newState;
        }

        // Rychlejší kontrola při zvýšené teplotě
        long interval = (mCurrentState == ThermalState.NORMAL)
            ? CHECK_INTERVAL_NORMAL : CHECK_INTERVAL_ELEVATED;
        scheduleCheck(interval);
    };

    private void scheduleCheck(long delayMs) {
        mHandler.postDelayed(mCheckRunnable, delayMs);
    }

    // ── Reakce na změnu stavu ─────────────────────────────────────────────────

    private void onStateChanged(ThermalState from, ThermalState to, float temp) {
        Log.w(TAG, String.format("Thermal state: %s → %s (%.1f°C)", from, to, temp));

        switch (to) {
            case NORMAL:
                // Zruš varování
                mNm.cancel(NOTIF_WARN);
                mNm.cancel(NOTIF_CRIT);
                break;

            case WARNING:
                showWarningNotification(temp);
                break;

            case CRITICAL:
                mNm.cancel(NOTIF_WARN);
                showCriticalNotification(temp);
                showCriticalDialog(temp);
                applyThrottling();
                break;

            case EMERGENCY:
                Log.e(TAG, "EMERGENCY: Temperature " + temp + "°C — initiating shutdown!");
                showEmergencyDialog(temp);
                // Dej uživateli 5 sekund před vypnutím
                mHandler.postDelayed(() -> emergencyShutdown(), 5_000);
                break;
        }
    }

    // ── Notifikace ────────────────────────────────────────────────────────────

    private void showWarningNotification(float temp) {
        Notification n = new Notification.Builder(mContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⚠️ Telefon se zahřívá")
            .setContentText(String.format(
                "Teplota: %.0f°C — Zavři náročné aplikace.", temp))
            .setColor(0xFFFF6F00)
            .setOngoing(true)
            .build();
        mNm.notify(NOTIF_WARN, n);
    }

    private void showCriticalNotification(float temp) {
        Notification n = new Notification.Builder(mContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("🔴 Přehřátí — výkon snížen")
            .setContentText(String.format(
                "Teplota: %.0f°C — Telefon je příliš horký!", temp))
            .setColor(0xFFD32F2F)
            .setOngoing(true)
            .build();
        mNm.notify(NOTIF_CRIT, n);
    }

    // ── Dialogy ───────────────────────────────────────────────────────────────

    private void showCriticalDialog(float temp) {
        NexusErrorDialog.show(mContext,
            NexusErrorDialog.ErrorType.THERMAL_CRITICAL,
            String.format("%.0f°C", temp),
            "Telefon je přehřátý. Výkon byl automaticky snížen.\n\n" +
            "• Zavři náročné aplikace\n" +
            "• Sniž jas displeje\n" +
            "• Polož telefon na rovný povrch\n" +
            "• Vypni Wi-Fi / Bluetooth pokud nepotřebuješ",
            /* dismissible */ true);
    }

    private void showEmergencyDialog(float temp) {
        NexusErrorDialog.show(mContext,
            NexusErrorDialog.ErrorType.THERMAL_EMERGENCY,
            String.format("%.0f°C", temp),
            "Telefon je kriticky přehřátý!\n\n" +
            "Automatické vypnutí za 5 sekund pro ochranu hardware.",
            /* dismissible */ false);
    }

    // ── Throttling & Shutdown ─────────────────────────────────────────────────

    private void applyThrottling() {
        // Nastaví thermal throttling přes sysfs
        ThermalWriter.setThrottleProfile("conservative");
        Log.w(TAG, "CPU throttling applied (conservative profile).");
    }

    private void emergencyShutdown() {
        Log.e(TAG, "Emergency thermal shutdown initiated.");
        try {
            mPm.reboot(null); // null = shutdown
        } catch (Exception e) {
            Log.e(TAG, "Shutdown failed: " + e.getMessage());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static ThermalState stateForTemp(float temp) {
        if (temp >= TEMP_SHUTDOWN)  return ThermalState.EMERGENCY;
        if (temp >= TEMP_CRITICAL)  return ThermalState.CRITICAL;
        if (temp >= TEMP_WARN)      return ThermalState.WARNING;
        return ThermalState.NORMAL;
    }

    public float getCurrentTemperature() { return mLastTemp; }
    public ThermalState getCurrentState() { return mCurrentState; }

    private void createNotificationChannels() {
        NotificationChannel ch = new NotificationChannel(
            CHANNEL_ID, "Tepelná ochrana",
            NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Upozornění na přehřátí telefonu");
        mNm.createNotificationChannel(ch);
    }
}
