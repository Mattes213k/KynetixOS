# packages/NexusSystemUI/Android.mk
# KynetixOS NexusSystemUI — build systémového UI
# Zahrnuje: Thermal, Battery, Crash, Error dialogy

LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE_TAGS := optional
LOCAL_MODULE      := NexusSystemUI
LOCAL_PACKAGE_NAME:= NexusSystemUI

LOCAL_PRIVILEGED_MODULE := true
LOCAL_CERTIFICATE       := platform

# ── Zdrojové soubory ──────────────────────────────────────────────────────────
LOCAL_SRC_FILES := $(call all-java-files-under, src)

# ── Resources ─────────────────────────────────────────────────────────────────
LOCAL_RESOURCE_DIR := $(LOCAL_PATH)/res

# ── Závislosti ────────────────────────────────────────────────────────────────
LOCAL_STATIC_JAVA_LIBRARIES := \
    androidx.core_core \
    androidx.appcompat_appcompat

LOCAL_JAVA_LIBRARIES := \
    android.car \
    services

# ── Systémová oprávnění (potřebná pro thermal sysfs, RecoverySystem) ──────────
LOCAL_USES_LIBRARIES := \
    android.hardware.thermal-V1-java

include $(BUILD_PACKAGE)
