# KynetixOS GSI — Generic System Image

## What is the GSI?

The KynetixOS GSI is a single system image that runs on **any Android device
with Project Treble support** (Android 9 / API 28 and above). It replaces only
the system partition — your device keeps its own vendor, kernel, and boot
images, so all hardware (Wi-Fi, camera, modem, sensors) continues to work via
the device's existing vendor HALs.

---

## Supported Devices

Any device that meets all of:

| Requirement | Detail |
|---|---|
| Project Treble | Android 9+ shipped with Treble enabled |
| Unlocked bootloader | Required to flash system partition |
| fastbootd support | Android 10+ recommended (dynamic partitions) |
| System partition ≥ 3 GB | GSI system.img is ~2.5 GB |
| Architecture | arm64 (covers virtually all devices since 2017) |

Tested compatible categories: Pixel, Samsung (Exynos & Snapdragon), OnePlus,
Xiaomi, Motorola, Sony, ASUS, Nokia, and most MediaTek arm64 devices.

---

## Differences vs the Sapphire (Xiaomi-specific) Build

| Feature | kynetix_sapphire | kynetix_gsi |
|---|---|---|
| Kernel | KynetixOS custom (5.15) | Device's own kernel |
| Vendor partition | Xiaomi sapphire blobs | Device's own vendor |
| SentinelLab TEE | Qualcomm QSEE (hw level 3) | Software-only (auto-upgrades if TEE HAL present) |
| NexusUI | ✓ | ✓ |
| NexusLauncher | ✓ | ✓ |
| NexusAntivirus | ✓ | ✓ |
| AuroraStore | ✓ | ✓ |
| Boot animation | ✓ | ✓ |
| NexusRecovery | ✓ (dedicated recovery partition) | Not flashed (use existing recovery) |

---

## Build Instructions

```bash
# Clone / place this repo at the root of your AOSP checkout, then:
cp build/target/kynetix_manifest.xml .repo/local_manifests/kynetix.xml
repo sync -j$(nproc)

# Build the GSI (arm64 + arm 32-bit support)
./build/tools/build_kynetix_gsi.sh arm64

# Output
# releases/KynetixOS_1.0.0_GSI_arm64_YYYYMMDD.zip
#   ├── system.img        ← flash this
#   ├── product.img       ← flash this (if device has product partition)
#   ├── system_ext.img    ← flash this (if device has system_ext partition)
#   └── FLASH_INSTRUCTIONS.txt
```

---

## Flashing Instructions (Quick)

```bash
# 1. Reboot to fastbootd (required for dynamic partitions)
adb reboot bootloader
fastboot reboot fastboot

# 2. Flash system image
fastboot flash system system.img

# 3. (Optional) flash product / system_ext
fastboot flash product product.img
fastboot flash system_ext system_ext.img

# 4. Wipe userdata and reboot
fastboot -w
fastboot reboot
```

> **Do NOT flash vendor.img, boot.img, or kernel** from the GSI package —
> these are not included and your device's existing ones must stay.

---

## SentinelLab on GSI

On GSI builds, SentinelLab runs in **software-only mode** by default:

- Pre-boot scan: ✓ (system integrity via dm-verity)
- Realtime monitor: ✓
- Network firewall: ✓
- Hardware TEE scan: auto-detected at runtime

If your device exposes a compatible TEE HAL (most modern Qualcomm, MediaTek,
and Samsung Exynos devices do), SentinelLab will automatically upgrade to
**hardware-assisted mode** on first boot without any configuration needed.

Check the current mode after booting:
```
adb shell getprop ro.sentinellab.tee_flavor
```

---

## Known Limitations

- **Camera**: relies on device vendor HAL. Most devices work. Some may require
  a camera2 compatibility layer from the vendor.
- **Fingerprint / Face unlock**: works on devices with standard HIDL/AIDL HALs.
- **NexusRecovery**: not flashed in GSI mode. Use your device's existing
  recovery (TWRP, OrangeFox, stock) to sideload updates.
- **Magisk / root**: can be applied on top of the GSI boot image as normal.
