#
# KynetixOS — device/gsi/kynetix/BoardConfig.mk
# GSI (Generic System Image) — compatible with all Project Treble Android devices
# Android 15 / KynetixOS 1.0
#

# ─── Architecture (arm64 + arm multilib — covers all modern Android devices) ───
TARGET_ARCH := arm64
TARGET_ARCH_VARIANT := armv8-a
TARGET_CPU_ABI := arm64-v8a
TARGET_CPU_ABI2 :=
TARGET_CPU_VARIANT := generic

TARGET_2ND_ARCH := arm
TARGET_2ND_ARCH_VARIANT := armv8-a
TARGET_2ND_CPU_ABI := armeabi-v7a
TARGET_2ND_CPU_ABI2 := armeabi
TARGET_2ND_CPU_VARIANT := generic

# ─── GSI: no board platform (generic) ────────────────────────────────────────
TARGET_BOARD_PLATFORM := generic

# ─── Partition layout (GSI uses system partition only) ───────────────────────
TARGET_NO_BOOTLOADER := true
TARGET_NO_KERNEL := true

BOARD_SYSTEMIMAGE_PARTITION_TYPE := ext4
BOARD_SYSTEM_EXTIMAGE_FILE_SYSTEM_TYPE := ext4
BOARD_PRODUCTIMAGE_FILE_SYSTEM_TYPE := ext4

TARGET_COPY_OUT_VENDOR := vendor
TARGET_COPY_OUT_PRODUCT := product
TARGET_COPY_OUT_SYSTEM_EXT := system_ext

# GSI uses a sparse system image
BOARD_BUILD_SYSTEM_ROOT_IMAGE := false
TARGET_USERIMAGES_USE_EXT4 := true

# ─── GSI flags ────────────────────────────────────────────────────────────────
# Allow missing vendor deps — vendor is provided by the device
ALLOW_MISSING_DEPENDENCIES := true
BUILD_BROKEN_ELF_PREBUILT_PRODUCT_COPY_FILES := true

# Vendor interface (VNDK) — GSI must not depend on vendor blobs
BOARD_VNDK_VERSION := current

# ─── AVB / Verified Boot ──────────────────────────────────────────────────────
# Disabled in GSI — device handles its own AVB
BOARD_AVB_ENABLE := false

# ─── SELinux — permissive during GSI bring-up, tighten per release ───────────
BOARD_VENDOR_SEPOLICY_DIRS += device/gsi/kynetix/sepolicy/vendor
SYSTEM_EXT_PRIVATE_SEPOLICY_DIRS += device/gsi/kynetix/sepolicy/private
SYSTEM_EXT_PUBLIC_SEPOLICY_DIRS  += device/gsi/kynetix/sepolicy/public

# ─── SentinelLab — software-only mode on GSI (no Qualcomm TEE assumption) ────
# Hardware TEE is available on most devices via the vendor HAL; SentinelLab
# will auto-detect and fall back to software-only if hw_scan is unavailable.
TARGET_TEE_FLAVOR := generic
SENTINELLAB_HW_SCAN := false
