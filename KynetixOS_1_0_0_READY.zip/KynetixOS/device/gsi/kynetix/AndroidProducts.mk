#
# KynetixOS — device/gsi/kynetix/AndroidProducts.mk
#
PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/device.mk

COMMON_LUNCH_CHOICES := \
    kynetix_gsi-user \
    kynetix_gsi-userdebug \
    kynetix_gsi-eng
