#
# KynetixOS — device/gsi/kynetix/device.mk
# GSI target — runs on any Project Treble-compliant Android device
# Replaces device/xiaomi/sapphire/device.mk
#

# ─── AOSP GSI base products ──────────────────────────────────────────────────
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/gsi_common.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/telephony.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/languages_full.mk)

# ─── KynetixOS vendor configuration ─────────────────────────────────────────
$(call inherit-product, vendor/kynetix/config/kynetix.mk)
$(call inherit-product, vendor/kynetix/security/sentinellab/sentinellab.mk)
$(call inherit-product, vendor/kynetix/overlay/nexusui.mk)

# ─── Product identity ─────────────────────────────────────────────────────────
PRODUCT_NAME     := kynetix_gsi
PRODUCT_DEVICE   := generic
PRODUCT_BRAND    := KynetixOS
PRODUCT_MODEL    := KynetixOS GSI
PRODUCT_MANUFACTURER := Kynetix

KYNETIX_VERSION    := 1.0.0
KYNETIX_BUILD_TYPE := OFFICIAL
KYNETIX_CODENAME   := Sapphire

PRODUCT_BUILD_PROP_OVERRIDES += \
    TARGET_PRODUCT=kynetix_gsi \
    PRODUCT_NAME=KynetixOS \
    BUILD_FINGERPRINT="Kynetix/KynetixOS/generic:15/AP3A.240905.015/$(shell date +%Y%m%d):user/release-keys"

# ─── Shipping API & density (GSI ships density-independent resources) ─────────
PRODUCT_SHIPPING_API_LEVEL := 34
PRODUCT_AAPT_CONFIG     := normal hdpi xhdpi xxhdpi xxxhdpi
PRODUCT_AAPT_PREF_CONFIG := xxhdpi

# ─── NexusUI overlays ─────────────────────────────────────────────────────────
DEVICE_PACKAGE_OVERLAYS += \
    vendor/kynetix/overlay/framework \
    vendor/kynetix/overlay/SystemUI \
    vendor/kynetix/overlay/Settings \
    vendor/kynetix/overlay/Launcher

PRODUCT_ENFORCE_RRO_TARGETS := *

# ─── KynetixOS core packages ──────────────────────────────────────────────────
PRODUCT_PACKAGES += \
    NexusLauncher \
    NexusSystemUI \
    NexusSettings \
    NexusAntivirus \
    SentinelLabService \
    AuroraStore \
    NexusWallpapers \
    NexusFonts \
    NexusRecovery

# ─── Sounds ───────────────────────────────────────────────────────────────────
PRODUCT_COPY_FILES += \
    vendor/kynetix/prebuilt/sounds/boot_complete.ogg:$(TARGET_COPY_OUT_PRODUCT)/media/audio/ui/boot_complete.ogg \
    vendor/kynetix/prebuilt/sounds/sentinel_scan.ogg:$(TARGET_COPY_OUT_PRODUCT)/media/audio/ui/sentinel_scan.ogg

# ─── Fonts ────────────────────────────────────────────────────────────────────
PRODUCT_COPY_FILES += \
    vendor/kynetix/prebuilt/fonts/NexusDisplay-Regular.ttf:$(TARGET_COPY_OUT_PRODUCT)/fonts/NexusDisplay-Regular.ttf \
    vendor/kynetix/prebuilt/fonts/NexusDisplay-Bold.ttf:$(TARGET_COPY_OUT_PRODUCT)/fonts/NexusDisplay-Bold.ttf \
    vendor/kynetix/prebuilt/fonts/NexusMono-Regular.ttf:$(TARGET_COPY_OUT_PRODUCT)/fonts/NexusMono-Regular.ttf

# ─── SentinelLab security (software-only for GSI compatibility) ───────────────
PRODUCT_COPY_FILES += \
    vendor/kynetix/security/sentinellab/sentinel_config.xml:$(TARGET_COPY_OUT_SYSTEM)/etc/sentinel_config.xml

# Note: sentinel_hwscan.te is omitted in GSI — hardware TEE policy is vendor-side

# ─── GSI: no device-specific kernel configs ───────────────────────────────────
# Kernel is supplied by the device. SentinelLab kernel cmdline args are
# optional; devices that don't honour them will fall back to software mode.

# ─── Properties ───────────────────────────────────────────────────────────────
PRODUCT_PROPERTY_OVERRIDES += \
    ro.kynetix.version=$(KYNETIX_VERSION) \
    ro.kynetix.build.type=$(KYNETIX_BUILD_TYPE) \
    ro.kynetix.codename=$(KYNETIX_CODENAME) \
    ro.nexusui.enabled=true \
    ro.sentinellab.enabled=true \
    ro.sentinellab.hw_access=false \
    ro.nexusantivirus.boot_scan=true \
    persist.sys.kynetix.theme=dark \
    persist.sys.kynetix.accent=0xFF2979FF \
    ro.product.gms_enabled=false \
    ro.aurorastore.bundled=true \
    ro.aurorastore.anonymous_mode=true

# ─── GSI: vndk and product interface ──────────────────────────────────────────
PRODUCT_PROPERTY_OVERRIDES += \
    ro.vndk.version=current

# ─── Permissions needed for GSI cross-device compat ──────────────────────────
PRODUCT_COPY_FILES += \
    frameworks/native/data/etc/android.hardware.telephony.gsm.xml:$(TARGET_COPY_OUT_SYSTEM)/etc/permissions/android.hardware.telephony.gsm.xml \
    frameworks/native/data/etc/android.hardware.telephony.cdma.xml:$(TARGET_COPY_OUT_SYSTEM)/etc/permissions/android.hardware.telephony.cdma.xml \
    frameworks/native/data/etc/android.software.sip.voip.xml:$(TARGET_COPY_OUT_SYSTEM)/etc/permissions/android.software.sip.voip.xml
